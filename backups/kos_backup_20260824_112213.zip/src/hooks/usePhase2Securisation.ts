import { useState, useCallback } from 'react';
import { computePhaseMetrics, usePhaseLoading, usePhaseLiveData } from '@/hooks/usePhaseDataCore';
import {
  phase2Stats,
  phase2Chantiers,
  phase2ExecutionLog,
  phase2Timeline,
  phase2Budget,
  phase2Dependencies,
} from '@/mocks/phase2Securisation';

export function usePhase2Securisation() {
  const [retryCount, setRetryCount] = useState(0);
  const loading = usePhaseLoading(retryCount);
  const retry = useCallback(() => setRetryCount(c => c + 1), []);
  const { liveData, isLive } = usePhaseLiveData(2);

  const m = computePhaseMetrics(phase2Chantiers, 32100000, 3800000, '2026-07-07', '2026-07-21');

  return {
    loading,
    retry,
    isLive,
    liveData,
    phase2Stats,
    phase2Chantiers,
    phase2ExecutionLog,
    phase2Timeline,
    phase2Budget,
    phase2Dependencies,
    openChantiers: m.openItems,
    inProgressChantiers: m.inProgressItems,
    completedChantiers: m.completedItems,
    totalActions: m.totalActions,
    completedActions: m.completedActions,
    inProgressActions: m.inProgressActions,
    globalProgress: m.globalProgress,
    criticalPathBlockers: m.criticalPathBlockers,
    daysRemaining: m.daysRemaining,
    budgetUtilizationPercent: m.budgetUtilizationPercent,
  };
}



