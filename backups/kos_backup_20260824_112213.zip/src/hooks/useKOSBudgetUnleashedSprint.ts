import { useState, useMemo, useCallback, useEffect } from 'react';
import { checkTableHealth } from '@/hooks/utils/hookMigration';
import {
  BUDGET_UNLEASHED_ACTIONS,
  computeBudgetUnleashedKPIs,
  BUDGET_UNLEASHED_META,
  type BudgetUnleashedAction,
  type BudgetUnleashedKPIs,
} from '@/mocks/budgetUnleashedSprint';

export type FilterStatus = 'all' | 'executed' | 'in_progress' | 'pending' | 'validating';
export type FilterCategory = 'all' | 'security' | 'performance' | 'compliance' | 'quality' | 'infrastructure' | 'growth' | 'data' | 'code';

export function useKOSBudgetUnleashedSprint() {
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('all');
  const [categoryFilter, setCategoryFilter] = useState<FilterCategory>('all');
  const [expandedActionId, setExpandedActionId] = useState<string | null>(null);
  const [selectedAction, setSelectedAction] = useState<BudgetUnleashedAction | null>(null);
  const [isLive, setIsLive] = useState(false);

  const kpis: BudgetUnleashedKPIs = useMemo(() => computeBudgetUnleashedKPIs(), []);
  const meta = BUDGET_UNLEASHED_META;

  useEffect(() => {
    checkTableHealth('kos_execution_logs').then(setIsLive);
  }, []);

  const filteredActions = useMemo(() => {
    return BUDGET_UNLEASHED_ACTIONS.filter(a => {
      if (statusFilter !== 'all' && a.executionStatus !== statusFilter) return false;
      if (categoryFilter !== 'all' && a.category !== categoryFilter) return false;
      return true;
    });
  }, [statusFilter, categoryFilter]);

  const toggleExpand = useCallback((id: string) => {
    setExpandedActionId(prev => (prev === id ? null : id));
  }, []);

  const openDetail = useCallback((action: BudgetUnleashedAction) => {
    setSelectedAction(action);
  }, []);

  const closeDetail = useCallback(() => {
    setSelectedAction(null);
  }, []);

  const statusCounts = useMemo(() => {
    return {
      all: BUDGET_UNLEASHED_ACTIONS.length,
      executed: BUDGET_UNLEASHED_ACTIONS.filter(a => a.executionStatus === 'executed').length,
      in_progress: BUDGET_UNLEASHED_ACTIONS.filter(a => a.executionStatus === 'in_progress').length,
      pending: BUDGET_UNLEASHED_ACTIONS.filter(a => a.executionStatus === 'pending').length,
      validating: BUDGET_UNLEASHED_ACTIONS.filter(a => a.executionStatus === 'validating').length,
    };
  }, []);

  return {
    actions: filteredActions,
    allActions: BUDGET_UNLEASHED_ACTIONS,
    kpis,
    meta,
    isLive,
    statusFilter,
    setStatusFilter,
    categoryFilter,
    setCategoryFilter,
    expandedActionId,
    toggleExpand,
    selectedAction,
    openDetail,
    closeDetail,
    statusCounts,
  };
}



