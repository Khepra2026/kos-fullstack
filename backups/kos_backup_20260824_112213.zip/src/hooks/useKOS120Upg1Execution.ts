import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  UPG1_HEADER,
  UPG1_TASKS,
  UPG1_METRICS,
  UPG1_TIMELINE,
  UPG1_RISKS,
  UPG1_AGENTS,
  UPG1_NEXT_STEPS,
} from '@/mocks/kos120Upg1Execution';

export function useKOS120Upg1Execution() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 400);
    return () => clearTimeout(t);
  }, []);

  const retry = useCallback(() => {
    setLoading(true);
    setTimeout(() => setLoading(false), 400);
  }, []);

  const header = useMemo(() => UPG1_HEADER, []);
  const tasks = useMemo(() => UPG1_TASKS, []);
  const metrics = useMemo(() => UPG1_METRICS, []);
  const timeline = useMemo(() => UPG1_TIMELINE, []);
  const risks = useMemo(() => UPG1_RISKS, []);
  const agents = useMemo(() => UPG1_AGENTS, []);
  const nextSteps = useMemo(() => UPG1_NEXT_STEPS, []);

  const criticalTasks = useMemo(() => tasks.filter((t) => t.priority === 'CRITIQUE'), [tasks]);
  const blockedTasks = useMemo(() => tasks.filter((t) => t.blockers.length > 0), [tasks]);
  const completedTasks = useMemo(() => tasks.filter((t) => t.status === 'completed'), [tasks]);
  const inProgressTasks = useMemo(() => tasks.filter((t) => t.status === 'in_progress'), [tasks]);

  return {
    loading,
    retry,
    header,
    tasks,
    metrics,
    timeline,
    risks,
    agents,
    nextSteps,
    criticalTasks,
    blockedTasks,
    completedTasks,
    inProgressTasks,
  };
}



