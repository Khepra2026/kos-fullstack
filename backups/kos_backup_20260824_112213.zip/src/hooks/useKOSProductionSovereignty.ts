import { useMemo, useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { PRODUCTION_WORKSTREAMS, computeProductionSovereigntyKPIs, type ProductionWorkstream, type SovereigntyAction } from '@/mocks/productionSovereignty';

export type PSVueActive = 'dashboard' | 'workstream' | 'actions' | 'timeline' | 'jalons' | 'dependances';

export interface PSFilterState {
  wsId: string | null;
  statut: string | null;
}

export function useKOSProductionSovereignty() {
  const [vueActive, setVueActive] = useState<PSVueActive>('dashboard');
  const [wsSelectionne, setWsSelectionne] = useState<string | null>(null);
  const [filters, setFilters] = useState<PSFilterState>({ wsId: null, statut: null });
  const [searchQuery, setSearchQuery] = useState('');
  const [isLive, setIsLive] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function checkLive() {
      try {
        const { data, error } = await supabase
          .from('kos_production_sovereignty')
          .select('*')
          .limit(1);
        if (!cancelled && !error && data && data.length > 0) {
          setIsLive(true);
        }
      } catch {
        // fallback mock
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    checkLive();
    return () => { cancelled = true; };
  }, []);

  const workstreams = PRODUCTION_WORKSTREAMS;
  const kpis = useMemo(() => computeProductionSovereigntyKPIs(), []);

  const allActions = useMemo(() => workstreams.flatMap(w => w.actions.map(a => ({ ...a, ws: w }))), [workstreams]);
  const allJalons = useMemo(() => workstreams.flatMap(w => w.jalons.map(j => ({ ...j, ws: w }))), [workstreams]);

  const actionsFiltrees = useMemo(() => {
    let result = allActions;
    if (filters.wsId) result = result.filter(a => a.ws.id === filters.wsId);
    if (filters.statut) result = result.filter(a => a.statut === filters.statut);
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(a =>
        a.action.toLowerCase().includes(q) || a.description.toLowerCase().includes(q) || a.ws.nom.toLowerCase().includes(q) || a.standardVise.toLowerCase().includes(q)
      );
    }
    return result;
  }, [allActions, filters, searchQuery]);

  const wsActuel = useMemo(() => {
    return wsSelectionne ? workstreams.find(w => w.id === wsSelectionne) || null : null;
  }, [wsSelectionne, workstreams]);

  const dependanceGraph = useMemo(() => {
    return workstreams.map(w => ({
      ws: w,
      bloquePar: w.actions.flatMap(a => a.dependances).filter((v, i, arr) => arr.indexOf(v) === i),
      bloque: [] as string[],
    })).map(node => {
      const bloqueIds = allActions.filter(a => a.dependances.some(d => node.ws.actions.find(wa => wa.id === d))).map(a => a.ws.id);
      return { ...node, bloque: [...new Set(bloqueIds)].filter(id => id !== node.ws.id) };
    });
  }, [workstreams, allActions]);

  const selectWs = (id: string | null) => {
    setWsSelectionne(id);
    setFilters(prev => ({ ...prev, wsId: id }));
    if (id) setVueActive('workstream');
  };

  const setFilter = (key: keyof PSFilterState, value: string | null) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const resetFilters = () => {
    setFilters({ wsId: null, statut: null });
    setSearchQuery('');
  };

  return {
    workstreams, kpis, allActions, allJalons, actionsFiltrees, wsActuel,
    vueActive, setVueActive, wsSelectionne, selectWs,
    filters, setFilter, resetFilters, searchQuery, setSearchQuery,
    dependanceGraph,
    isLive,
    loading,
  };
}



