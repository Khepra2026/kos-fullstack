import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import {
  bankingStackOverview,
  layer1_dataIngestion,
  layer2_dataProcessing,
  layer3_intelligenceCore,
  layer4_orchestrationEngine,
  layer5_outputFactory,
  layer6_observability,
  endToEndFlow,
  techStackMapping,
  bankingStackKPIs,
  bankingStackDecisionLogic,
} from '@/mocks/bankingStack';

export function useKOSBankingStack() {
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(false);
  const [data, setData] = useState<typeof mockData | null>(null);

  const mockData = {
    overview: bankingStackOverview,
    layer1: layer1_dataIngestion,
    layer2: layer2_dataProcessing,
    layer3: layer3_intelligenceCore,
    layer4: layer4_orchestrationEngine,
    layer5: layer5_outputFactory,
    layer6: layer6_observability,
    flow: endToEndFlow,
    tech: techStackMapping,
    kpis: bankingStackKPIs,
    logic: bankingStackDecisionLogic,
  };

  useEffect(() => {
    let cancelled = false;
    async function init() {
      try {
        const { data: db } = await supabase.from('regulatory_alerts').select('id').limit(1);
        if (!cancelled && db && db.length > 0) setIsLive(true);
      } catch { /* fallback mock */ }
      if (!cancelled) { setData(mockData); setLoading(false); }
    }
    init();
    return () => { cancelled = true; };
  }, []);

  return { loading, isLive, data };
}



