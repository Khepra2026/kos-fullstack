import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import {
  beacTexts,
  beacCountries,
  beacInspections,
  beacKPIs,
  beacOverview,
  beacBigFourAnalysis,
  type BEACText,
  type BEACInspection,
} from '@/mocks/observatoireBEAC';

export function useObservatoireBEAC() {
  const [loading, setLoading] = useState(true);
  const [dataSource, setDataSource] = useState<'live' | 'mock'>('mock');
  const [liveAlerts, setLiveAlerts] = useState<BEACText[]>([]);
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [selectedTextType, setSelectedTextType] = useState<string>('all');
  const [selectedImpact, setSelectedImpact] = useState<string>('all');
  const [selectedInspectionStatus, setSelectedInspectionStatus] = useState<string>('all');

  const fetchLiveData = useCallback(async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('regulatory_alerts')
        .select('id, title, authority, alert_type, severity, compliance_deadline, impact_assessment, affected_business_units, created_at')
        .or('authority.ilike.%BEAC%,authority.ilike.%CEMAC%')
        .order('created_at', { ascending: false })
        .limit(8);

      if (!error && data && data.length > 0) {
        const mapped: BEACText[] = data.map((a: any) => ({
          id: `live-${a.id}`,
          reference: `BEAC-${a.alert_type?.toUpperCase()}-${String(a.id).padStart(3, '0')}`,
          title: a.title,
          type: 'Note' as const,
          year: 2026,
          countryScope: a.affected_business_units || ['CEMAC'],
          verified: true,
          khepraStatus: 'veille' as const,
          impactLevel: (a.severity === 'critical' ? 'critique' : a.severity === 'high' ? 'élevé' : 'moyen') as any,
          summary: a.impact_assessment || a.title,
          clientActions: ['Analyse KHEPRA', 'Veille réglementaire'],
          citationCount: 0,
          lastVerified: a.created_at?.split('T')[0] || new Date().toISOString().split('T')[0],
        }));
        setLiveAlerts(mapped);
        setDataSource('live');
      } else {
        setDataSource('mock');
      }
    } catch {
      setDataSource('mock');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchLiveData();
  }, [fetchLiveData]);

  useEffect(() => {
    const channel = supabase
      .channel('beac_regulatory_alerts_realtime')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'regulatory_alerts',
      }, (payload) => {
        const auth = (payload.new as any)?.authority || '';
        if (auth.toLowerCase().includes('beac') || auth.toLowerCase().includes('cemac')) {
          fetchLiveData();
        }
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [fetchLiveData]);

  const allTexts: BEACText[] = [...liveAlerts, ...beacTexts].slice(0, 24);

  const filteredTexts: BEACText[] = allTexts.filter(t => {
    const countryMatch = selectedCountry === 'all' || t.countryScope.includes(selectedCountry);
    const typeMatch = selectedTextType === 'all' || t.type === selectedTextType;
    const impactMatch = selectedImpact === 'all' || t.impactLevel === selectedImpact;
    return countryMatch && typeMatch && impactMatch;
  });

  const filteredInspections: BEACInspection[] = beacInspections.filter(i => {
    const statusMatch = selectedInspectionStatus === 'all' || i.status === selectedInspectionStatus;
    const countryMatch = selectedCountry === 'all' || i.country === selectedCountry;
    return statusMatch && countryMatch;
  });

  return {
    overview: beacOverview,
    kpis: beacKPIs,
    texts: filteredTexts,
    allTexts,
    countries: beacCountries,
    inspections: filteredInspections,
    allInspections: beacInspections,
    bigFour: beacBigFourAnalysis,
    selectedCountry, setSelectedCountry,
    selectedTextType, setSelectedTextType,
    selectedImpact, setSelectedImpact,
    selectedInspectionStatus, setSelectedInspectionStatus,
    dataSource, loading,
    refresh: fetchLiveData,
  };
}



