import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { EXPERTS, EXPERT_AGENTS, EXPERT_GLOBAL_METRICS, type Expert, type ExpertAgent } from '@/mocks/bloc07ExpertNetwork';

interface UseExpertNetworkReturn {
  experts: Expert[];
  agents: ExpertAgent[];
  globalMetrics: typeof EXPERT_GLOBAL_METRICS;
  isLive: boolean;
  loading: boolean;
  error: string | null;
  refetch: () => void;
}

export function useExpertNetwork(): UseExpertNetworkReturn {
  const [experts, setExperts] = useState<Expert[]>([]);
  const [agents] = useState<ExpertAgent[]>(EXPERT_AGENTS);
  const [globalMetrics] = useState(EXPERT_GLOBAL_METRICS);
  const [isLive, setIsLive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null);
    try { 
      const { data } = await supabase.from('expert_reviews').select('id').limit(1);
      if (data && data.length > 0) setIsLive(true);
      setExperts(EXPERTS); 
    } catch (err: unknown) { const msg = err instanceof Error ? err.message : 'Erreur'; setError(msg); setExperts(EXPERTS); } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);
  return { experts, agents, globalMetrics, isLive, loading, error, refetch: fetchData };
}



