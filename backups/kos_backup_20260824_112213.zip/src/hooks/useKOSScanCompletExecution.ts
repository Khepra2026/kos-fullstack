import { useState, useMemo, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import {
  SCAN_DOMAINS,
  SCAN_REMAINING_TASKS,
  EXECUTION_BLOCKS,
  computeGlobalStats,
  type ScanDomain,
  type ScanRemainingTask,
  type ScanExecutionBlock,
  type ScanGlobalStats,
} from '@/mocks/scanCompletExecution';

export interface UseKOSScanCompletExecutionResult {
  domains: ScanDomain[];
  tasks: ScanRemainingTask[];
  blocks: ScanExecutionBlock[];
  globalStats: ScanGlobalStats;
  scanRunning: boolean;
  scanProgress: number;
  scanPhase: string;
  scanMessage: string;
  scanCompleted: boolean;
  executingBlock: string | null;
  executingAll: boolean;
  executionsDone: number;
  toastMessage: string | null;
  isLive: boolean;
  loading: boolean;
  startFullScan: () => Promise<void>;
  executeBlock: (blockId: string) => Promise<void>;
  executeAllBlocks: () => Promise<void>;
  dismissToast: () => void;
}

const SCAN_PHASES = [
  { id: 'init', label: 'Initialisation Multi-Scanner — Connexion Supabase + Edge Functions', pct: 0 },
  { id: 'integrity', label: 'Scan Intégrité Système — 2 847 fichiers · 412 850 lignes de code', pct: 15 },
  { id: 'agents', label: 'Scan Performance Agents — 75 agents IA · 7 domaines', pct: 28 },
  { id: 'security', label: 'Scan Sécurité — 6 couches OWASP/RLS/NPM/Headers', pct: 42 },
  { id: 'compliance', label: 'Scan Conformité — BCEAO/COBAC/GAFI/ISO 37301', pct: 56 },
  { id: 'seo', label: 'Scan SEO/GEO — CWV/Indexation/Schema.org/Backlinks', pct: 70 },
  { id: 'content', label: 'Scan Contenu — 200+ assets éditoriaux · Blog/KBR/LinkedIn', pct: 82 },
  { id: 'business', label: 'Scan Business — Pipeline/CRM/Croissance/Upsell', pct: 92 },
  { id: 'compile', label: 'Compilation Rapport Exécutif — KPIs Big Four consolidés', pct: 100 },
];

export function useKOSScanCompletExecution(): UseKOSScanCompletExecutionResult {
  const [scanRunning, setScanRunning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanPhase, setScanPhase] = useState('');
  const [scanMessage, setScanMessage] = useState('');
  const [scanCompleted, setScanCompleted] = useState(false);
  const [executingBlock, setExecutingBlock] = useState<string | null>(null);
  const [executingAll, setExecutingAll] = useState(false);
  const [executionsDone, setExecutionsDone] = useState(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isLive, setIsLive] = useState(false);
  const [loading, setLoading] = useState(true);

  const [blocks, setBlocks] = useState<ScanExecutionBlock[]>(EXECUTION_BLOCKS);

  useEffect(() => {
    supabase
      .from('kos_execution_logs')
      .select('id')
      .limit(1)
      .then(({ data }) => {
        if (data && data.length > 0) setIsLive(true);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const globalStats = useMemo(() => computeGlobalStats(), []);

  const dismissToast = useCallback(() => setToastMessage(null), []);

  const startFullScan = useCallback(async () => {
    setScanRunning(true);
    setScanProgress(0);
    setScanCompleted(false);
    setScanMessage('🚀 Initialisation du Scan Complet KOS — Connexion à Supabase...');

    for (let i = 0; i < SCAN_PHASES.length; i++) {
      const phase = SCAN_PHASES[i];
      setScanPhase(`Phase ${i + 1}/${SCAN_PHASES.length} — ${phase.label}`);
      setScanMessage(phase.label);

      const steps = 5;
      const startPct = i === 0 ? 0 : SCAN_PHASES[i - 1].pct;
      const endPct = phase.pct;
      for (let s = 1; s <= steps; s++) {
        const midPct = startPct + Math.round(((endPct - startPct) * s) / steps);
        setScanProgress(midPct);
        await new Promise((r) => setTimeout(r, 300 + Math.random() * 300));
      }
    }

    setScanProgress(100);
    setScanPhase('Scan Terminé — Rapport Exécutif compilé');
    setScanMessage(
      `✅ Scan Complet terminé. ${globalStats.totalTasks} tâches restantes · ${globalStats.totalCritical} critiques P0 · ${globalStats.totalAutoFixable} auto-fixables · ${globalStats.executionBlocksPending}/${globalStats.executionBlocksCount} blocs en attente. Score global : ${globalStats.avgHealthScore}/100.`
    );
    await new Promise((r) => setTimeout(r, 800));

    setScanRunning(false);
    setScanCompleted(true);
    setToastMessage(
      `Scan Complet KOS terminé — ${globalStats.totalTasks} tâches restantes, ${globalStats.totalCritical} critiques, ${globalStats.executionBlocksPending} blocs prêts à exécuter.`
    );
    setTimeout(() => setToastMessage(null), 8000);
  }, [globalStats]);

  const executeBlock = useCallback(
    async (blockId: string) => {
      setExecutingBlock(blockId);
      const block = blocks.find((b) => b.id === blockId);
      if (!block) return;

      setToastMessage(`⚡ Exécution du bloc "${block.label}" — ${block.tasksCount} tâches en cours...`);

      // Simulate execution with progress
      const steps = block.tasksCount;
      for (let i = 1; i <= steps; i++) {
        await new Promise((r) => setTimeout(r, 600 + Math.random() * 500));
        setToastMessage(`⚡ "${block.label}" — ${i}/${steps} tâches exécutées...`);
      }

      // Mark block as completed
      setBlocks((prev) =>
        prev.map((b) => (b.id === blockId ? { ...b, status: 'completed' as const } : b)),
      );
      setExecutionsDone((prev) => prev + 1);
      setExecutingBlock(null);
      setToastMessage(`✅ Bloc "${block.label}" exécuté avec succès — ${block.tasksCount}/${block.tasksCount} tâches. Impact : ${block.globalImpact}`);
      setTimeout(() => setToastMessage(null), 6000);
    },
    [blocks],
  );

  const executeAllBlocks = useCallback(async () => {
    setExecutingAll(true);
    setToastMessage('🔥 EXÉCUTION GLOBALE — Tous les blocs en séquence...');

    const pendingBlocks = blocks.filter((b) => b.status === 'pending');
    if (pendingBlocks.length === 0) {
      setToastMessage('✅ Aucun bloc en attente. Toutes les corrections sont déjà appliquées.');
      setExecutingAll(false);
      return;
    }

    for (let i = 0; i < pendingBlocks.length; i++) {
      const block = pendingBlocks[i];
      setToastMessage(`🔥 Exécution globale — Bloc ${i + 1}/${pendingBlocks.length} : "${block.label}"...`);
      await executeBlock(block.id);
      await new Promise((r) => setTimeout(r, 400));
    }

    setExecutingAll(false);
    setToastMessage(
      `🎉 EXÉCUTION GLOBALE TERMINÉE — ${pendingBlocks.length}/${pendingBlocks.length} blocs exécutés. Toutes les tâches restantes sont traitées. Score cible : 100/100 Big Four.`,
    );
    setTimeout(() => setToastMessage(null), 10000);
  }, [blocks, executeBlock]);

  return {
    domains: SCAN_DOMAINS,
    tasks: SCAN_REMAINING_TASKS,
    blocks,
    globalStats,
    scanRunning,
    scanProgress,
    scanPhase,
    scanMessage,
    scanCompleted,
    executingBlock,
    executingAll,
    executionsDone,
    toastMessage,
    isLive,
    loading,
    startFullScan,
    executeBlock,
    executeAllBlocks,
    dismissToast,
  };
}



