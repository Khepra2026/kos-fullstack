import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import {
  ODSKE_DASHBOARD_METRICS,
  ODSKE_DOMAIN_CATALOG,
  ODSKE_SOURCES_MOCK,
  ODSKE_PROVENANCE_MOCK,
  ODSKE_VALIDATION_RULES_MOCK,
  ODSKE_QUALITY_REPORTS_MOCK,
  ODSKE_AGENT_ACTIVITY_MOCK,
  ODSKE_KNOWLEDGE_REGULATORY_MOCK,
  ODSKE_WATCHLIST_MOCK,
  ODSKE_GOVERNANCE_LOG_MOCK,
  type ODSKEMetric,
  type ODSKEDomainCatalog,
  type ODSKESourceRegistry,
  type ODSKEProvenanceLog,
  type ODSKEValidationRule,
  type ODSKEQualityReport,
  type ODSKEAgentActivity,
  type ODSKEKnowledgeRegulatory,
  type ODSKEWatchlist,
  type ODSKEGovernanceLog,
} from '@/mocks/odskeDashboard';

interface UseODSKEDashboardReturn {
  metrics: ODSKEMetric[];
  domains: ODSKEDomainCatalog[];
  sources: ODSKESourceRegistry[];
  provenance: ODSKEProvenanceLog[];
  validationRules: ODSKEValidationRule[];
  qualityReports: ODSKEQualityReport[];
  agentActivity: ODSKEAgentActivity[];
  knowledgeRegulatory: ODSKEKnowledgeRegulatory[];
  watchlists: ODSKEWatchlist[];
  governanceLog: ODSKEGovernanceLog[];
  isLive: boolean;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  liveTables: string[];
}

export function useODSKEDashboard(): UseODSKEDashboardReturn {
  const [metrics, setMetrics] = useState<ODSKEMetric[]>(ODSKE_DASHBOARD_METRICS);
  const [domains, setDomains] = useState<ODSKEDomainCatalog[]>(ODSKE_DOMAIN_CATALOG);
  const [sources, setSources] = useState<ODSKESourceRegistry[]>(ODSKE_SOURCES_MOCK);
  const [provenance, setProvenance] = useState<ODSKEProvenanceLog[]>(ODSKE_PROVENANCE_MOCK);
  const [validationRules, setValidationRules] = useState<ODSKEValidationRule[]>(ODSKE_VALIDATION_RULES_MOCK);
  const [qualityReports, setQualityReports] = useState<ODSKEQualityReport[]>(ODSKE_QUALITY_REPORTS_MOCK);
  const [agentActivity, setAgentActivity] = useState<ODSKEAgentActivity[]>(ODSKE_AGENT_ACTIVITY_MOCK);
  const [knowledgeRegulatory, setKnowledgeRegulatory] = useState<ODSKEKnowledgeRegulatory[]>(ODSKE_KNOWLEDGE_REGULATORY_MOCK);
  const [watchlists, setWatchlists] = useState<ODSKEWatchlist[]>(ODSKE_WATCHLIST_MOCK);
  const [governanceLog, setGovernanceLog] = useState<ODSKEGovernanceLog[]>(ODSKE_GOVERNANCE_LOG_MOCK);
  const [isLive, setIsLive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [liveTables, setLiveTables] = useState<string[]>([]);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    const live: string[] = [];

    try {
      const [
        metricsRes, domainsRes, sourcesRes, provenanceRes,
        rulesRes, reportsRes, agentsRes, knowledgeRes,
        watchRes, govRes,
      ] = await Promise.all([
        supabase.from('kos_odske_dashboard').select('*').order('domain'),
        supabase.from('kos_odske_data_catalog').select('domain, count').order('domain'),
        supabase.from('kos_odske_source_registry').select('*').order('trust_level'),
        supabase.from('kos_odske_provenance_log').select('*').order('last_collected', { ascending: false }),
        supabase.from('kos_odske_validation_rules').select('*').order('severity'),
        supabase.from('kos_odske_quality_reports').select('*').order('generated_at', { ascending: false }),
        supabase.from('kos_odske_agent_activity').select('*').order('started_at', { ascending: false }),
        supabase.from('kos_odske_knowledge_regulatory').select('*').order('publication_date', { ascending: false }).limit(50),
        supabase.from('kos_odske_watchlist').select('*').order('check_frequency'),
        supabase.from('kos_odske_governance_log').select('*').order('created_at', { ascending: false }).limit(30),
      ]);

      if (metricsRes.data && metricsRes.data.length > 0) {
        setMetrics(metricsRes.data as ODSKEMetric[]);
        live.push('dashboard');
      }
      if (domainsRes.data && domainsRes.data.length > 0) {
        const aggregated: Record<string, number> = {};
        (domainsRes.data as any[]).forEach((row: any) => {
          aggregated[row.domain] = (aggregated[row.domain] || 0) + 1;
        });
        setDomains(Object.entries(aggregated).map(([domain, tables_count]) => ({ domain, tables_count })));
        live.push('data_catalog');
      }
      if (sourcesRes.data && sourcesRes.data.length > 0) {
        setSources(sourcesRes.data as ODSKESourceRegistry[]);
        live.push('source_registry');
      }
      if (provenanceRes.data && provenanceRes.data.length > 0) {
        setProvenance(provenanceRes.data as ODSKEProvenanceLog[]);
        live.push('provenance');
      }
      if (rulesRes.data && rulesRes.data.length > 0) {
        setValidationRules(rulesRes.data as ODSKEValidationRule[]);
        live.push('validation_rules');
      }
      if (reportsRes.data && reportsRes.data.length > 0) {
        setQualityReports(reportsRes.data as ODSKEQualityReport[]);
        live.push('quality_reports');
      }
      if (agentsRes.data && agentsRes.data.length > 0) {
        setAgentActivity(agentsRes.data as ODSKEAgentActivity[]);
        live.push('agent_activity');
      }
      if (knowledgeRes.data && knowledgeRes.data.length > 0) {
        setKnowledgeRegulatory(knowledgeRes.data as ODSKEKnowledgeRegulatory[]);
        live.push('knowledge_regulatory');
      }
      if (watchRes.data && watchRes.data.length > 0) {
        setWatchlists(watchRes.data as ODSKEWatchlist[]);
        live.push('watchlist');
      }
      if (govRes.data && govRes.data.length > 0) {
        setGovernanceLog(govRes.data as ODSKEGovernanceLog[]);
        live.push('governance_log');
      }

      setIsLive(live.length >= 5);
      setLiveTables(live);
    } catch (err: any) {
      setError(err.message || 'Erreur de connexion Supabase');
      setIsLive(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  return {
    metrics, domains, sources, provenance, validationRules,
    qualityReports, agentActivity, knowledgeRegulatory,
    watchlists, governanceLog,
    isLive, loading, error, refresh: fetchAll, liveTables,
  };
}



