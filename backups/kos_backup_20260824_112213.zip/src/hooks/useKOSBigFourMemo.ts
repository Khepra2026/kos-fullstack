import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { bigFourMemoMockHistory } from '@/mocks/bigFourExecutiveMemo';

export interface BigFourMemo {
  memo_id: string;
  memo_code: string;
  executive_summary: string;
  context: { objectif: string; perimetre: string; date: string; documents_analyses: number };
  findings: Array<{ texte: string; source: string; reference: string; confiance: string; article?: string }>;
  risks: Array<{ type: string; niveau: string; mitigation: string }>;
  recommendations: Array<{ priorite: string; action: string; delai: string; impact: string }>;
  decision_required: boolean;
  qa_score: number;
  confidence_level: string;
  agents: string[];
  sources_count: number;
  compliance: string;
  generated_at?: string;
}

export function useKOSBigFourMemo() {
  const [loading, setLoading] = useState(false);
  const [memo, setMemo] = useState<BigFourMemo | null>(null);

  const generateViaRpc = async (query: string): Promise<BigFourMemo> => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { data, error } = await supabase.rpc('kos_bigfour_memo_generator', {
        p_query: query,
        p_user_id: user?.id || null,
      });
      if (error) throw error;
      setMemo(data as BigFourMemo);
      return data as BigFourMemo;
    } catch {
      // Fallback to simulated memo
      const fallback = bigFourMemoMockHistory[0];
      const simulated = {
        ...fallback,
        memo_id: `memo-${Date.now()}`,
        memo_code: `KOS-MEMO-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        context: {
          ...fallback.context,
          objectif: `Analyse réglementaire ${query}`,
          date: new Date().toLocaleDateString('fr-FR'),
        },
      };
      setMemo(simulated as BigFourMemo);
      return simulated as BigFourMemo;
    } finally {
      setLoading(false);
    }
  };

  const generate = generateViaRpc;

  return { generate, loading, memo, setMemo };
}



