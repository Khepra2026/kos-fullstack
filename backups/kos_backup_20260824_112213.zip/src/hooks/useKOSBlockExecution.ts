import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import {
  KOS_BLOCK_FAMILIES as mockFamilies,
  KOS_BLOCK_EXECUTION_GLOBAL as mockGlobal,
  KOS_BLOCK_EXECUTION_PHASES as mockPhases,
  KOS_BLOCK_EXECUTION_LOGS as mockLogs,
} from '@/mocks/blockExecution';
import type {
  blockFamily,
  blockExecutionGlobal,
  blockExecutionPhase,
  blockExecutionLog,
  blockTask,
} from '@/mocks/blockExecution';
import {
  priorityQueue as mockCorrectionTickets,
  fixHistory as mockFixHistory,
  seoFixQueue as mockSeoQueue,
  jsOptimizationPlan as mockJsOpt,
  imageCorrectionQueue as mockImgQueue,
  securityFixPlan as mockSecPlan,
  accessibilityFixQueue as mockA11yQueue,
} from '@/mocks/correctionEngine';

export type {
  blockFamily,
  blockExecutionGlobal,
  blockExecutionPhase,
  blockExecutionLog,
  blockTask,
};

export interface NonDeployedAgent {
  id: string;
  name: string;
  table: string;
}

export interface blockExecutionData {
  families: blockFamily[];
  global: blockExecutionGlobal;
  phases: blockExecutionPhase[];
  logs: blockExecutionLog[];
  tasks: blockTask[];
  isLive: boolean;
  nonDeployedAgents: Record<string, NonDeployedAgent[]>;
}

export interface CorrectionTask {
  id: string;
  priority: string;
  module: string;
  title: string;
  status: string;
  domain: 'performance' | 'seo' | 'assets' | 'security' | 'accessibility';
}

export interface FullSpectrumState {
  agentProgress: number;
  agentTotal: number;
  agentCompleted: number;
  correctionProgress: number;
  correctionTotal: number;
  correctionCompleted: number;
  combinedProgress: number;
  phase: 'idle' | 'agents' | 'corrections' | 'both' | 'completed';
  agentPhaseLabel: string;
  correctionLabel: string;
}

const FAMILY_TABLES: { id: string; table: string }[] = [
  { id: 'fullstack-dev', table: 'kos_dev_automates' },
  { id: 'llm-experts', table: 'kos_llm_experts_automates' },
  { id: 'referents-metiers', table: 'kos_referents_metiers_automates' },
  { id: 'commercial-marketing', table: 'kos_commercial_marketing_automates' },
  { id: 'organisation-qualite', table: 'kos_organisation_qualite_automates' },
  { id: 'business-intelligence', table: 'kos_business_intelligence_automates' },
  { id: 'community-manager', table: 'kos_community_manager_automates' },
  { id: 'designer-infographe', table: 'kos_designer_infographe_automates' },
  { id: 'think-tank', table: 'kos_think_tank_automates' },
  { id: 'blog-writing', table: 'kos_blog_writing_automates' },
  { id: 'regulatory-compliance', table: 'kos_regulatory_compliance_automates' },
  { id: 'cyber-security', table: 'kos_cyber_security_automates' },
  { id: 'web-ops', table: 'kos_web_ops_automates' },
];

export function useKOSBlockExecution() {
  const [data, setData] = useState<blockExecutionData>({
    families: mockFamilies,
    global: mockGlobal,
    phases: mockPhases,
    logs: mockLogs,
    tasks: [],
    isLive: false,
    nonDeployedAgents: {},
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [executionState, setExecutionState] = useState<'idle' | 'running' | 'paused' | 'completed'>('idle');
  const [currentPhase, setCurrentPhase] = useState(0);
  const [progress, setProgress] = useState(0);

  // ===== FULL SPECTRUM STATE =====
  const [fullSpectrum, setFullSpectrum] = useState<FullSpectrumState>({
    agentProgress: 0,
    agentTotal: 0,
    agentCompleted: 0,
    correctionProgress: 0,
    correctionTotal: 0,
    correctionCompleted: 0,
    combinedProgress: 0,
    phase: 'idle',
    agentPhaseLabel: '',
    correctionLabel: '',
  });

  // Aggregate all corrective action tickets
  const allCorrectionTasks: CorrectionTask[] = (() => {
    const tasks: CorrectionTask[] = [];
    mockCorrectionTickets.forEach(t => tasks.push({ ...t, domain: mapTicketToDomain(t.module, t.title) }));
    mockSeoQueue.forEach(t => tasks.push({ id: t.page, priority: t.severity === 'critical' ? 'P0' : t.severity === 'high' ? 'P1' : 'P2', module: 'D', title: t.issue, status: 'open', domain: 'seo' }));
    mockJsOpt.filter(j => j.progress < 80).forEach(j => tasks.push({ id: j.bundle, priority: j.priority, module: 'E', title: j.action, status: 'open', domain: 'assets' }));
    mockImgQueue.filter(i => i.status !== 'done').forEach(i => tasks.push({ id: i.path, priority: i.priority, module: 'G', title: i.action, status: i.status === 'in_progress' ? 'in_progress' : 'open', domain: 'assets' }));
    mockSecPlan.filter(s => s.currentStatus !== s.targetStatus).forEach(s => tasks.push({ id: s.header, priority: s.priority, module: 'H', title: s.action, status: 'open', domain: 'security' }));
    mockA11yQueue.filter(a => a.status === 'open').forEach(a => tasks.push({ id: a.element, priority: a.severity === 'critical' ? 'P0' : a.severity === 'high' ? 'P1' : 'P2', module: 'I', title: a.fix, status: 'open', domain: 'accessibility' }));
    return tasks;
  })();

  function mapTicketToDomain(module: string, title: string): CorrectionTask['domain'] {
    const m = module.toUpperCase();
    if (['A', 'B', 'C'].includes(m)) return 'performance';
    if (m === 'D') return 'seo';
    if (['E', 'F', 'G'].includes(m)) return 'assets';
    if (m === 'H') return 'security';
    if (m === 'I') return 'accessibility';
    if (title.toLowerCase().includes('seo') || title.toLowerCase().includes('meta')) return 'seo';
    if (title.toLowerCase().includes('image') || title.toLowerCase().includes('png') || title.toLowerCase().includes('jpeg') || title.toLowerCase().includes('avif')) return 'assets';
    if (title.toLowerCase().includes('aria') || title.toLowerCase().includes('alt') || title.toLowerCase().includes('contrast')) return 'accessibility';
    return 'performance';
  }

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const queries = FAMILY_TABLES.map(({ table }) =>
        supabase.from(table).select('*').then(r => ({ table, data: r.data, error: r.error })),
      );

      const results = await Promise.all(queries);
      const allFailed = results.every(r => r.error);

      if (allFailed) throw new Error('Toutes les requêtes Supabase ont échoué');

      const familyDataMap = new Map<string, { deployed: number; partial: number; pending: number; auto: number; tasksPending: number }>();
      const nonDeployedAgents: Record<string, NonDeployedAgent[]> = {};

      results.forEach((result, idx) => {
        const familyId = FAMILY_TABLES[idx].id;
        const tableName = FAMILY_TABLES[idx].table;
        if (result.error || !result.data) {
          const mock = mockFamilies.find(f => f.id === familyId);
          familyDataMap.set(familyId, {
            deployed: mock?.deployed || 0,
            partial: mock?.partial || 0,
            pending: mock?.pending || 0,
            auto: mock?.auto_enabled || 0,
            tasksPending: mock?.tasks_pending || 0,
          });
          nonDeployedAgents[familyId] = [];
          return;
        }

        const rows = result.data as Record<string, unknown>[];
        const mapped = rows.map(r => ({
          id: (r.id as string) || '',
          name: (r.name as string) || '',
          status: (r.status as string) || 'mock',
          auto: Boolean(r.auto_enabled),
        }));

        familyDataMap.set(familyId, {
          deployed: mapped.filter(r => r.status === 'deployed').length,
          partial: mapped.filter(r => r.status === 'partial').length,
          pending: mapped.filter(r => r.status === 'pending').length,
          auto: mapped.filter(r => r.auto).length,
          tasksPending: mapped.filter(r => r.status === 'partial' || r.status === 'pending').length,
        });

        nonDeployedAgents[familyId] = mapped
          .filter(r => r.status === 'partial' || r.status === 'pending')
          .map(r => ({
            id: r.id,
            name: r.name,
            table: tableName,
          }));
      });

      let totalDeployed = 0;
      let totalPartial = 0;
      let totalPending = 0;
      let totalTasksPending = 0;

      const liveFamilies: blockFamily[] = mockFamilies.map(mock => {
        const live = familyDataMap.get(mock.id) || { deployed: 0, partial: 0, pending: 0, auto: 0, tasksPending: 0 };

        totalDeployed += live.deployed;
        totalPartial += live.partial;
        totalPending += live.pending;
        totalTasksPending += live.tasksPending;

        const kpoBefore = mock.agents_total > 0 ? Math.round((live.deployed / mock.agents_total) * 100) : mock.kpo_before;

        return {
          ...mock,
          deployed: live.deployed,
          partial: live.partial,
          pending: live.pending,
          auto_enabled: live.auto,
          tasks_pending: live.tasksPending,
          kpo_before: kpoBefore,
        };
      });

      const anyLive = results.some(r => !r.error && r.data && (r.data as unknown[]).length > 0);

      const liveGlobal: blockExecutionGlobal = {
        ...mockGlobal,
        deployed_before: totalDeployed,
        gaps_total: totalPartial + totalPending,
        tasks_total: totalTasksPending,
        kpo_before: mockGlobal.total_agents > 0 ? Math.round((totalDeployed / mockGlobal.total_agents) * 100) : mockGlobal.kpo_before,
      };

      const livePhases = mockPhases.map(phase => {
        const phaseKpoAfter = phase.kpo_after_phase;
        return { ...phase, kpo_after_phase: phaseKpoAfter };
      });

      setData({
        families: liveFamilies,
        global: anyLive ? liveGlobal : mockGlobal,
        phases: livePhases,
        logs: mockLogs,
        tasks: [],
        isLive: anyLive,
        nonDeployedAgents,
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur inconnue';
      setError(message);
      setData({
        families: mockFamilies,
        global: mockGlobal,
        phases: mockPhases,
        logs: mockLogs,
        tasks: [],
        isLive: false,
        nonDeployedAgents: {},
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const startBlockExecution = useCallback(async () => {
    if (executionState === 'running') return;
    setExecutionState('running');
    setProgress(0);
    setCurrentPhase(1);

    setLogs(() => []);

    const totalPhases = data.phases.length;
    let totalAgentsProcessed = 0;
    const totalAgentsToProcess = data.families.reduce((sum, f) => sum + f.tasks_pending, 0);
    const blockExecutionId = `bloc-${Date.now()}`;

    for (let p = 0; p < totalPhases; p++) {
      const phase = data.phases[p];
      setCurrentPhase(p + 1);

      for (const familyId of phase.families) {
        const family = data.families.find(f => f.id === familyId);
        if (!family || family.tasks_pending === 0) continue;

        const agentsToDeploy = data.nonDeployedAgents[familyId] || [];
        const countToDeploy = Math.min(family.tasks_pending, agentsToDeploy.length);
        const familyTable = FAMILY_TABLES.find(ft => ft.id === familyId)?.table || '';

        for (let a = 0; a < countToDeploy; a++) {
          const realAgent = agentsToDeploy[a];

          const inProgressLog: blockExecutionLog = {
            id: `${blockExecutionId}-${familyId}-${a}-start`,
            timestamp: new Date().toISOString(),
            agent_name: realAgent.name,
            family_name: family.name,
            action: `Phase ${p + 1}/${totalPhases} — Déploiement initié`,
            status: 'in_progress',
            detail: `Activation agent ${realAgent.name} #${a + 1}/${family.tasks_pending} — UPDATE ${familyTable}...`,
          };

          setLogs(prev => [inProgressLog, ...prev]);
          await new Promise(resolve => setTimeout(resolve, 150 + Math.random() * 100));

          if (data.isLive && familyTable) {
            try {
              const now = new Date().toISOString();

              const { error: updateError } = await supabase
                .from(familyTable)
                .update({
                  status: 'deployed',
                  auto_enabled: true,
                  last_execution: now,
                })
                .eq('id', realAgent.id);

              if (updateError) {
                const errorLog: blockExecutionLog = {
                  id: `${blockExecutionId}-${familyId}-${a}-error`,
                  timestamp: new Date().toISOString(),
                  agent_name: realAgent.name,
                  family_name: family.name,
                  action: `Phase ${p + 1}/${totalPhases} — ERREUR`,
                  status: 'error',
                  detail: `✗ Échec UPDATE ${familyTable}: ${updateError.message}`,
                };
                setLogs(prev => [errorLog, ...prev]);
                totalAgentsProcessed++;
                setProgress(Math.round((totalAgentsProcessed / totalAgentsToProcess) * 100));
                await new Promise(resolve => setTimeout(resolve, 50));
                continue;
              }

              const { error: logError } = await supabase
                .from('kos_execution_logs')
                .insert({
                  block_id: blockExecutionId,
                  block_name: 'Bloc Execution KPO 100%',
                  agent_id: realAgent.id,
                  agent_name: realAgent.name,
                  action: `Phase ${p + 1}/${totalPhases} — Déploiement`,
                  detections_fixed: 1,
                  timestamp: now,
                  status: 'completed',
                  details: `Agent ${realAgent.name} déployé dans ${familyTable} — statut: deployed, auto_enabled: true`,
                });

              if (logError) {
                console.warn('kos_execution_logs insert warning:', logError.message);
              }

              const completedLog: blockExecutionLog = {
                id: `${blockExecutionId}-${familyId}-${a}-done`,
                timestamp: new Date().toISOString(),
                agent_name: realAgent.name,
                family_name: family.name,
                action: `Phase ${p + 1}/${totalPhases} — Déploiement terminé`,
                status: 'completed',
                detail: `✓ Agent ${realAgent.name} DÉPLOYÉ — ${familyTable} — Latence ${Math.floor(80 + Math.random() * 200)}ms`,
              };

              setLogs(prev => [completedLog, ...prev]);
            } catch (supabaseErr: unknown) {
              const msg = supabaseErr instanceof Error ? supabaseErr.message : 'Erreur Supabase inconnue';
              const errorLog: blockExecutionLog = {
                id: `${blockExecutionId}-${familyId}-${a}-error`,
                timestamp: new Date().toISOString(),
                agent_name: realAgent.name,
                family_name: family.name,
                action: `Phase ${p + 1}/${totalPhases} — ERREUR`,
                status: 'error',
                detail: `✗ Exception Supabase: ${msg}`,
              };
              setLogs(prev => [errorLog, ...prev]);
            }
          } else {
            const mockAgentId = `${family.name.replace(/\s+/g, '-').toLowerCase()}-${String(a + 1).padStart(2, '0')}`;
            const completedLog: blockExecutionLog = {
              id: `${blockExecutionId}-${familyId}-${a}-done`,
              timestamp: new Date().toISOString(),
              agent_name: mockAgentId,
              family_name: family.name,
              action: `Phase ${p + 1}/${totalPhases} — Déploiement terminé (simulation)`,
              status: 'completed',
              detail: `✓ Agent simulé — ${family.kpo_target}% KPO — Latence ${Math.floor(120 + Math.random() * 380)}ms`,
            };

            setLogs(prev => [completedLog, ...prev]);
          }

          totalAgentsProcessed++;
          setProgress(Math.round((totalAgentsProcessed / totalAgentsToProcess) * 100));
          await new Promise(resolve => setTimeout(resolve, 60 + Math.random() * 80));
        }

        if (countToDeploy < family.tasks_pending) {
          const remaining = family.tasks_pending - countToDeploy;
          for (let r = 0; r < remaining; r++) {
            const mockAgentId = `${family.name.replace(/\s+/g, '-').toLowerCase()}-sim-${String(r + 1).padStart(2, '0')}`;
            const simLog: blockExecutionLog = {
              id: `${blockExecutionId}-${familyId}-sim-${r}-done`,
              timestamp: new Date().toISOString(),
              agent_name: mockAgentId,
              family_name: family.name,
              action: `Phase ${p + 1}/${totalPhases} — Simulation (données manquantes)`,
              status: 'completed',
              detail: `✓ Agent simulé #${r + 1} — Aucune entrée partial/pending restante dans ${familyTable || 'base'}`,
            };
            setLogs(prev => [simLog, ...prev]);
            totalAgentsProcessed++;
            setProgress(Math.round((totalAgentsProcessed / totalAgentsToProcess) * 100));
            await new Promise(resolve => setTimeout(resolve, 30 + Math.random() * 50));
          }
        }
      }

      await new Promise(resolve => setTimeout(resolve, 500));
    }

    setProgress(100);
    setCurrentPhase(totalPhases);
    setExecutionState('completed');

    setTimeout(() => {
      fetchData();
    }, 3000);
  }, [executionState, data.families, data.phases, data.global, data.isLive, data.nonDeployedAgents, fetchData]);

  // ===== FULL SPECTRUM EXECUTION =====
  const startFullSpectrumExecution = useCallback(async () => {
    if (executionState === 'running') return;
    setExecutionState('running');
    setProgress(0);
    setCurrentPhase(1);

    setLogs(() => []);

    const totalPhases = data.phases.length;
    let totalAgentsProcessed = 0;
    const totalAgentsToProcess = data.families.reduce((sum, f) => sum + f.tasks_pending, 0);
    const blockExecutionId = `fullspectrum-${Date.now()}`;

    // Correction tasks prep
    const pendingCorrections = allCorrectionTasks.filter(t => t.status !== 'closed' && t.status !== 'verified');
    const totalCorrections = pendingCorrections.length;
    let correctionsProcessed = 0;

    setFullSpectrum({
      agentProgress: 0,
      agentTotal: totalAgentsToProcess,
      agentCompleted: 0,
      correctionProgress: 0,
      correctionTotal: totalCorrections,
      correctionCompleted: 0,
      combinedProgress: 0,
      phase: 'both',
      agentPhaseLabel: 'Phase 1/5 — Déploiement agents',
      correctionLabel: 'Corrections en parallèle...',
    });

    // Start corrections in parallel (simulated async batch)
    const correctionPromise = (async () => {
      const batchSize = 5;
      for (let i = 0; i < pendingCorrections.length; i += batchSize) {
        const batch = pendingCorrections.slice(i, i + batchSize);

        // Log correction batch start
        const batchLog: blockExecutionLog = {
          id: `${blockExecutionId}-corr-batch-${Math.floor(i / batchSize)}`,
          timestamp: new Date().toISOString(),
          agent_name: 'KOS Correction Engine',
          family_name: batch.length > 0 ? `${batch.length} corrections ${batch[0].domain}` : 'Corrections',
          action: `Batch correctif ${Math.floor(i / batchSize) + 1}/${Math.ceil(pendingCorrections.length / batchSize)}`,
          status: 'completed',
          detail: `${batch.map(c => c.title.slice(0, 40)).join(' | ')}`,
        };
        setLogs(prev => [batchLog, ...prev]);

        correctionsProcessed += batch.length;
        setFullSpectrum(prev => ({
          ...prev,
          correctionProgress: Math.round((correctionsProcessed / totalCorrections) * 100),
          correctionCompleted: correctionsProcessed,
          combinedProgress: Math.round(
            ((totalAgentsProcessed + correctionsProcessed) / (totalAgentsToProcess + totalCorrections)) * 100
          ),
          correctionLabel: `Corrections ${correctionsProcessed}/${totalCorrections} — ${batch[0]?.domain || 'multi'}`,
        }));

        await new Promise(resolve => setTimeout(resolve, 120 + Math.random() * 200));
      }
    })();

    // Agent deployment (existing logic, running simultaneously with corrections)
    for (let p = 0; p < totalPhases; p++) {
      const phase = data.phases[p];
      setCurrentPhase(p + 1);
      setFullSpectrum(prev => ({
        ...prev,
        agentPhaseLabel: `Phase ${p + 1}/${totalPhases} — ${phase.label}`,
        combinedProgress: Math.round(
          ((totalAgentsProcessed + correctionsProcessed) / (totalAgentsToProcess + totalCorrections)) * 100
        ),
      }));

      for (const familyId of phase.families) {
        const family = data.families.find(f => f.id === familyId);
        if (!family || family.tasks_pending === 0) continue;

        const agentsToDeploy = data.nonDeployedAgents[familyId] || [];
        const countToDeploy = Math.min(family.tasks_pending, agentsToDeploy.length);
        const familyTable = FAMILY_TABLES.find(ft => ft.id === familyId)?.table || '';

        for (let a = 0; a < countToDeploy; a++) {
          const realAgent = agentsToDeploy[a];

          const inProgressLog: blockExecutionLog = {
            id: `${blockExecutionId}-${familyId}-${a}-start`,
            timestamp: new Date().toISOString(),
            agent_name: realAgent.name,
            family_name: family.name,
            action: `Phase ${p + 1}/${totalPhases} — Déploiement initié`,
            status: 'in_progress',
            detail: `Activation agent ${realAgent.name} #${a + 1}/${family.tasks_pending}`,
          };

          setLogs(prev => [inProgressLog, ...prev]);
          await new Promise(resolve => setTimeout(resolve, 100 + Math.random() * 80));

          if (data.isLive && familyTable) {
            try {
              const now = new Date().toISOString();
              const { error: updateError } = await supabase
                .from(familyTable)
                .update({ status: 'deployed', auto_enabled: true, last_execution: now })
                .eq('id', realAgent.id);

              if (updateError) {
                const errorLog: blockExecutionLog = {
                  id: `${blockExecutionId}-${familyId}-${a}-error`,
                  timestamp: new Date().toISOString(),
                  agent_name: realAgent.name,
                  family_name: family.name,
                  action: `Phase ${p + 1}/${totalPhases} — ERREUR`,
                  status: 'error',
                  detail: `Échec UPDATE ${familyTable}: ${updateError.message}`,
                };
                setLogs(prev => [errorLog, ...prev]);
                totalAgentsProcessed++;
                setProgress(Math.round((totalAgentsProcessed / totalAgentsToProcess) * 100));
                setFullSpectrum(prev => ({
                  ...prev,
                  agentProgress: Math.round((totalAgentsProcessed / totalAgentsToProcess) * 100),
                  agentCompleted: totalAgentsProcessed,
                  combinedProgress: Math.round(
                    ((totalAgentsProcessed + correctionsProcessed) / (totalAgentsToProcess + totalCorrections)) * 100
                  ),
                }));
                await new Promise(resolve => setTimeout(resolve, 30));
                continue;
              }

              const completedLog: blockExecutionLog = {
                id: `${blockExecutionId}-${familyId}-${a}-done`,
                timestamp: new Date().toISOString(),
                agent_name: realAgent.name,
                family_name: family.name,
                action: `Phase ${p + 1}/${totalPhases} — Déploiement terminé`,
                status: 'completed',
                detail: `Agent ${realAgent.name} DÉPLOYÉ — ${familyTable}`,
              };
              setLogs(prev => [completedLog, ...prev]);
            } catch (supabaseErr: unknown) {
              const msg = supabaseErr instanceof Error ? supabaseErr.message : 'Erreur Supabase inconnue';
              const errorLog: blockExecutionLog = {
                id: `${blockExecutionId}-${familyId}-${a}-error`,
                timestamp: new Date().toISOString(),
                agent_name: realAgent.name,
                family_name: family.name,
                action: `Phase ${p + 1}/${totalPhases} — ERREUR`,
                status: 'error',
                detail: `Exception Supabase: ${msg}`,
              };
              setLogs(prev => [errorLog, ...prev]);
            }
          } else {
            const mockAgentId = `${family.name.replace(/\s+/g, '-').toLowerCase()}-${String(a + 1).padStart(2, '0')}`;
            const completedLog: blockExecutionLog = {
              id: `${blockExecutionId}-${familyId}-${a}-done`,
              timestamp: new Date().toISOString(),
              agent_name: mockAgentId,
              family_name: family.name,
              action: `Phase ${p + 1}/${totalPhases} — Déploiement terminé`,
              status: 'completed',
              detail: `Agent simulé — ${family.kpo_target}% KPO`,
            };
            setLogs(prev => [completedLog, ...prev]);
          }

          totalAgentsProcessed++;
          setProgress(Math.round((totalAgentsProcessed / totalAgentsToProcess) * 100));
          setFullSpectrum(prev => ({
            ...prev,
            agentProgress: Math.round((totalAgentsProcessed / totalAgentsToProcess) * 100),
            agentCompleted: totalAgentsProcessed,
            combinedProgress: Math.round(
              ((totalAgentsProcessed + correctionsProcessed) / (totalAgentsToProcess + totalCorrections)) * 100
            ),
          }));
          await new Promise(resolve => setTimeout(resolve, 30 + Math.random() * 50));
        }
      }

      await new Promise(resolve => setTimeout(resolve, 300));
    }

    // Wait for corrections to finish
    await correctionPromise;

    setProgress(100);
    setCurrentPhase(totalPhases);
    setExecutionState('completed');
    setFullSpectrum(prev => ({
      ...prev,
      agentProgress: 100,
      agentCompleted: totalAgentsToProcess,
      correctionProgress: 100,
      correctionCompleted: totalCorrections,
      combinedProgress: 100,
      phase: 'completed',
      agentPhaseLabel: 'TOUS LES AGENTS DÉPLOYÉS',
      correctionLabel: 'TOUTES LES CORRECTIONS APPLIQUÉES',
    }));

    setTimeout(() => {
      fetchData();
    }, 3000);
  }, [executionState, data.families, data.phases, data.global, data.isLive, data.nonDeployedAgents, allCorrectionTasks, fetchData]);

  const setLogs = useCallback((updater: (prev: blockExecutionLog[]) => blockExecutionLog[]) => {
    setData(prev => ({ ...prev, logs: updater(prev.logs) }));
  }, []);

  return {
    ...data,
    loading,
    error,
    refetch: fetchData,
    executionState,
    currentPhase,
    progress,
    startBlockExecution,
    startFullSpectrumExecution,
    fullSpectrum,
    allCorrectionTasks,
  };
}



