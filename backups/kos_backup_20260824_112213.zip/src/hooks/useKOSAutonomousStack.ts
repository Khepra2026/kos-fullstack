import { useState, useMemo, useCallback } from 'react';
import {
  EXTERNAL_DEPENDENCIES,
  FACTORY_SYSTEMS,
  SUBSTITUTION_PROPOSALS,
  MIGRATION_PHASES,
  ARCHITECTURE_LAYERS,
  AUTONOMY_KPIS,
  AUTONOMY_ASSESSMENT,
  AUTONOMOUS_STACK_STATS,
} from '@/mocks/autonomousStack';
import type {
  ExternalDependency,
  FactorySystem,
  SubstitutionProposal,
  MigrationPhase,
  MigrationTask,
  ArchitectureLayer,
  AutonomyKPI,
  AutonomyAssessment,
} from '@/mocks/autonomousStack';

export function useKOSAutonomousStack() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDependencyId, setSelectedDependencyId] = useState<string | null>(null);

  // ─── DEPENDENCY DIAGNOSTIC ──────────────────────────────────────────────

  const allDependencies = useMemo(() => EXTERNAL_DEPENDENCIES, []);

  const criticalDependencies = useMemo(
    () => EXTERNAL_DEPENDENCIES.filter(d => d.criticality === 'P0-critical'),
    []
  );

  const replaceableDependencies = useMemo(
    () => EXTERNAL_DEPENDENCIES.filter(d => d.replaceable),
    []
  );

  const nonReplaceableDependencies = useMemo(
    () => EXTERNAL_DEPENDENCIES.filter(d => !d.replaceable),
    []
  );

  const getDependencyById = useCallback(
    (id: string): ExternalDependency | undefined =>
      EXTERNAL_DEPENDENCIES.find(d => d.id === id),
    []
  );

  const getDependenciesByCategory = useCallback(
    (category: string): ExternalDependency[] =>
      EXTERNAL_DEPENDENCIES.filter(d => d.category === category),
    []
  );

  const searchDependencies = useCallback(
    (query: string): ExternalDependency[] => {
      const q = query.toLowerCase();
      return EXTERNAL_DEPENDENCIES.filter(
        d =>
          d.name.toLowerCase().includes(q) ||
          d.provider.toLowerCase().includes(q) ||
          d.description.toLowerCase().includes(q) ||
          d.usedBy.some(u => u.toLowerCase().includes(q)) ||
          d.replacementOption.toLowerCase().includes(q)
      );
    },
    []
  );

  const dependencyStats = useMemo(() => {
    const totalCost = EXTERNAL_DEPENDENCIES.reduce((s, d) => s + d.currentCostMonthlyFCFA, 0);
    const replaceableCost = replaceableDependencies.reduce((s, d) => s + d.currentCostMonthlyFCFA, 0);
    const criticalCount = criticalDependencies.length;
    const replaceableCount = replaceableDependencies.length;
    return { totalCost, replaceableCost, criticalCount, replaceableCount };
  }, [replaceableDependencies, criticalDependencies]);

  // ─── SUBSTITUTION MATRIX ───────────────────────────────────────────────

  const allProposals = useMemo(() => SUBSTITUTION_PROPOSALS, []);

  const getProposalByDependencyId = useCallback(
    (depId: string): SubstitutionProposal | undefined =>
      SUBSTITUTION_PROPOSALS.find(p => p.dependencyId === depId),
    []
  );

  const getProposalsByPhase = useCallback(
    (phase: number): SubstitutionProposal[] =>
      SUBSTITUTION_PROPOSALS.filter(p => p.recommendedPhase === phase),
    []
  );

  const getProposalsByStatus = useCallback(
    (status: string): SubstitutionProposal[] =>
      SUBSTITUTION_PROPOSALS.filter(p => p.status === status),
    []
  );

  const inProgressProposals = useMemo(
    () => SUBSTITUTION_PROPOSALS.filter(p => p.status === 'in_progress'),
    []
  );

  const substitutionStats = useMemo(() => {
    const totalSavings = SUBSTITUTION_PROPOSALS.reduce(
      (s, p) => s + p.costReduction,
      0
    );
    const avgFeasibility = Math.round(
      SUBSTITUTION_PROPOSALS.reduce((s, p) => s + p.feasibilityScore, 0) /
        SUBSTITUTION_PROPOSALS.length
    );
    const completed = SUBSTITUTION_PROPOSALS.filter(
      p => p.status === 'completed' || p.status === 'in_progress'
    ).length;
    return { totalSavings, avgFeasibility, completed, total: SUBSTITUTION_PROPOSALS.length };
  }, []);

  // ─── MIGRATION PIPELINE ─────────────────────────────────────────────────

  const allPhases = useMemo(() => MIGRATION_PHASES, []);

  const getPhaseById = useCallback(
    (id: string): MigrationPhase | undefined =>
      MIGRATION_PHASES.find(p => p.id === id),
    []
  );

  const getActivePhase = useMemo(
    () => MIGRATION_PHASES.find(p => p.status === 'in_progress'),
    []
  );

  const getTasksByStatus = useCallback(
    (status: string): MigrationTask[] => {
      const tasks: MigrationTask[] = [];
      MIGRATION_PHASES.forEach(phase => {
        phase.tasks.forEach(task => {
          if (task.status === status) tasks.push(task);
        });
      });
      return tasks;
    },
    []
  );

  const migrationStats = useMemo(() => {
    let totalTasks = 0;
    let completedTasks = 0;
    let inProgressTasks = 0;
    let blockedTasks = 0;
    MIGRATION_PHASES.forEach(phase => {
      totalTasks += phase.tasks.length;
      completedTasks += phase.tasks.filter(t => t.status === 'completed').length;
      inProgressTasks += phase.tasks.filter(t => t.status === 'in_progress').length;
      blockedTasks += phase.tasks.filter(t => t.status === 'blocked').length;
    });
    const overallProgress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    return { totalTasks, completedTasks, inProgressTasks, blockedTasks, overallProgress };
  }, []);

  const getDependencyMigrationStatus = useCallback(
    (depId: string): { phase: string; tasks: MigrationTask[]; progress: number } => {
      const allTasks: MigrationTask[] = [];
      let phaseName = 'Non planifié';
      MIGRATION_PHASES.forEach(phase => {
        const tasks = phase.tasks.filter(t => t.dependencyId === depId);
        if (tasks.length > 0) {
          phaseName = phase.name.replace('Phase ', 'P');
          allTasks.push(...tasks);
        }
      });
      const completed = allTasks.filter(t => t.status === 'completed').length;
      const progress = allTasks.length > 0 ? Math.round((completed / allTasks.length) * 100) : 0;
      return { phase: phaseName, tasks: allTasks, progress };
    },
    []
  );

  // ─── FACTORY SYSTEMS ────────────────────────────────────────────────────

  const allFactories = useMemo(() => FACTORY_SYSTEMS, []);

  const activeFactories = useMemo(
    () => FACTORY_SYSTEMS.filter(f => f.currentStatus === 'operational'),
    []
  );

  const getFactoryById = useCallback(
    (id: string): FactorySystem | undefined =>
      FACTORY_SYSTEMS.find(f => f.id === id),
    []
  );

  const factoryStats = useMemo(() => {
    const avgAutomation = Math.round(
      FACTORY_SYSTEMS.reduce((s, f) => s + f.automationRate, 0) / FACTORY_SYSTEMS.length
    );
    const avgDependency = Math.round(
      FACTORY_SYSTEMS.reduce((s, f) => s + f.externalDependencyRate, 0) / FACTORY_SYSTEMS.length
    );
    return { avgAutomation, avgDependency, total: FACTORY_SYSTEMS.length };
  }, []);

  // ─── ARCHITECTURE ──────────────────────────────────────────────────────

  const allLayers = useMemo(() => ARCHITECTURE_LAYERS, []);

  const getLayerById = useCallback(
    (id: string): ArchitectureLayer | undefined =>
      ARCHITECTURE_LAYERS.find(l => l.id === id),
    []
  );

  const architectureSummary = useMemo(() => {
    const avgAutonomyNow = Math.round(
      ARCHITECTURE_LAYERS.reduce((s, l) => s + l.autonomyNow, 0) / ARCHITECTURE_LAYERS.length
    );
    const avgAutonomyTarget = Math.round(
      ARCHITECTURE_LAYERS.reduce((s, l) => s + l.autonomyTarget, 0) / ARCHITECTURE_LAYERS.length
    );
    const totalComponents = ARCHITECTURE_LAYERS.reduce((s, l) => s + l.keyComponents.length, 0);
    const activeComponents = ARCHITECTURE_LAYERS.reduce(
      (s, l) => s + l.keyComponents.filter(c => c.status === 'active').length,
      0
    );
    return { avgAutonomyNow, avgAutonomyTarget, totalComponents, activeComponents };
  }, []);

  // ─── KPIs ───────────────────────────────────────────────────────────────

  const allKPIs = useMemo(() => AUTONOMY_KPIS, []);

  const getKPIsByLayer = useCallback(
    (layer: string): AutonomyKPI[] =>
      AUTONOMY_KPIS.filter(k => k.layer === layer),
    []
  );

  const kpiTrends = useMemo(() => {
    const improving = AUTONOMY_KPIS.filter(k => k.trend === 'up');
    const declining = AUTONOMY_KPIS.filter(k => k.trend === 'down');
    return { improving: improving.length, declining: declining.length, total: AUTONOMY_KPIS.length };
  }, []);

  // ─── AUTONOMY ASSESSMENT ───────────────────────────────────────────────

  const assessments = useMemo(() => AUTONOMY_ASSESSMENT, []);

  const getAssessmentByDimension = useCallback(
    (dimension: string): AutonomyAssessment | undefined =>
      AUTONOMY_ASSESSMENT.find(a => a.dimension === dimension),
    []
  );

  const weightedScore = useMemo(() => {
    return AUTONOMY_ASSESSMENT.reduce(
      (sum, a) => sum + a.score * (a.weight / 100),
      0
    );
  }, []);

  // ─── GLOBAL SEARCH ─────────────────────────────────────────────────────

  const performSearch = useCallback(
    (query: string) => {
      setSearchQuery(query);
      if (!query.trim()) return;
      const deps = searchDependencies(query);
      if (deps.length > 0 && !selectedDependencyId) {
        setSelectedDependencyId(deps[0].id);
      }
    },
    [searchDependencies, selectedDependencyId]
  );

  const clearSelection = useCallback(() => {
    setSelectedDependencyId(null);
    setSearchQuery('');
  }, []);

  // ─── STATS ──────────────────────────────────────────────────────────────

  const getStats = useCallback(() => AUTONOMOUS_STACK_STATS, []);

  return {
    // Dependencies
    dependencies: allDependencies,
    criticalDependencies,
    replaceableDependencies,
    nonReplaceableDependencies,
    getDependencyById,
    getDependenciesByCategory,
    searchDependencies,
    dependencyStats,
    selectedDependencyId,
    setSelectedDependencyId,

    // Substitutions
    proposals: allProposals,
    getProposalByDependencyId,
    getProposalsByPhase,
    getProposalsByStatus,
    inProgressProposals,
    substitutionStats,

    // Migration
    phases: allPhases,
    getPhaseById,
    activePhase: getActivePhase,
    getTasksByStatus,
    migrationStats,
    getDependencyMigrationStatus,

    // Factories
    factories: allFactories,
    activeFactories,
    getFactoryById,
    factoryStats,

    // Architecture
    layers: allLayers,
    getLayerById,
    architectureSummary,

    // KPIs
    kpis: allKPIs,
    getKPIsByLayer,
    kpiTrends,

    // Assessment
    assessments,
    getAssessmentByDimension,
    weightedScore,

    // Search
    searchQuery,
    performSearch,
    clearSelection,

    // Stats
    stats: AUTONOMOUS_STACK_STATS,
    getStats,
  };
}



