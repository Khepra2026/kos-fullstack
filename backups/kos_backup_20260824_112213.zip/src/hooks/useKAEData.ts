import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import {
  kaeRules as mockRules,
  kaeTriggers as mockTriggers,
  kaeAgents as mockAgents,
  kaeDocuments as mockDocs,
  kaePlugins as mockPlugins,
  kaeConfigurations as mockConfigs,
  kaeNotifications as mockNotifs,
  kaeGlobalStats as mockStats,
} from '@/mocks/automationEngine';

interface UseKAEDataReturn {
  loading: boolean;
  error: string | null;
  isLive: boolean;
  rules: typeof mockRules;
  triggers: typeof mockTriggers;
  agents: typeof mockAgents;
  documents: typeof mockDocs;
  plugins: typeof mockPlugins;
  configurations: typeof mockConfigs;
  notifications: typeof mockNotifs;
  globalStats: typeof mockStats;
  refetch: () => void;
}

/** Normalise une règle KAE depuis Supabase vers le format mock */
function normalizeRule(row: Record<string, unknown>) {
  return {
    id: String(row.id || row.rule_id || ''),
    ruleId: String(row.rule_id || row.id || ''),
    ruleName: String(row.rule_name || ''),
    ruleCategory: String(row.rule_category || ''),
    description: String(row.description || ''),
    conditionJson: (row.condition_json as Record<string, unknown>) || {},
    actionType: String(row.action_type || ''),
    actionConfig: (row.action_config as Record<string, unknown>) || {},
    priority: String(row.priority || 'medium'),
    isActive: Boolean(row.is_active),
    versionNumber: Number(row.version_number || 1),
    triggerCount: Number(row.trigger_count || 0),
    evaluationCount: Number(row.evaluation_count || 0),
    tags: (row.tags as string[]) || [],
    createdAt: String(row.created_at || new Date().toISOString()),
    updatedAt: String(row.updated_at || new Date().toISOString()),
  };
}

function normalizeTrigger(row: Record<string, unknown>) {
  return {
    id: String(row.id || row.trigger_id || ''),
    triggerId: String(row.trigger_id || row.id || ''),
    triggerName: String(row.trigger_name || ''),
    triggerType: String(row.trigger_type || ''),
    description: String(row.description || ''),
    configJson: (row.config_json as Record<string, unknown>) || {},
    targetWorkflowId: String(row.target_workflow_id || ''),
    targetRuleIds: (row.target_rule_ids as string[]) || [],
    isActive: Boolean(row.is_active),
    lastFiredAt: String(row.last_fired_at || ''),
    fireCount: Number(row.fire_count || 0),
    tags: (row.tags as string[]) || [],
  };
}

function normalizeAgent(row: Record<string, unknown>) {
  return {
    id: String(row.id || row.agent_id || ''),
    agentId: String(row.agent_id || row.id || ''),
    agentName: String(row.agent_name || ''),
    role: String(row.role || ''),
    domain: String(row.domain || ''),
    capabilities: (row.capabilities as string[]) || [],
    dependencies: (row.dependencies as string[]) || [],
    version: String(row.version || '1.0'),
    status: String(row.status || 'active'),
    edgeFunctionRef: String(row.edge_function_ref || ''),
    usageMetrics: (row.usage_metrics as Record<string, unknown>) || {},
    executionCount: Number(row.execution_count || 0),
    successRate: Number(row.success_rate || 0),
    tags: (row.tags as string[]) || [],
  };
}

export function useKAEData(): UseKAEDataReturn {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isLive, setIsLive] = useState(false);
  const [rules, setRules] = useState(mockRules);
  const [triggers, setTriggers] = useState(mockTriggers);
  const [agents, setAgents] = useState(mockAgents);
  const [documents, setDocuments] = useState(mockDocs);
  const [plugins, setPlugins] = useState(mockPlugins);
  const [configurations, setConfigurations] = useState(mockConfigs);
  const [notifications, setNotifications] = useState(mockNotifs);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    let anyLive = false;

    try {
      // Fetch KAE rules from Supabase
      const { data: rulesData, error: rulesErr } = await supabase
        .from('kae_rules')
        .select('*')
        .order('created_at', { ascending: false });

      if (rulesErr) throw rulesErr;
      if (rulesData && rulesData.length > 0) {
        setRules(rulesData.map(normalizeRule) as typeof mockRules);
        anyLive = true;
      } else {
        setRules(mockRules);
      }
    } catch {
      setRules(mockRules);
    }

    try {
      const { data: trigData, error: trigErr } = await supabase
        .from('kae_triggers')
        .select('*')
        .order('created_at', { ascending: false });

      if (!trigErr && trigData && trigData.length > 0) {
        setTriggers(trigData.map(normalizeTrigger) as typeof mockTriggers);
        anyLive = true;
      } else {
        setTriggers(mockTriggers);
      }
    } catch {
      setTriggers(mockTriggers);
    }

    try {
      const { data: agentData, error: agentErr } = await supabase
        .from('kae_agent_registry')
        .select('*')
        .order('registered_at', { ascending: false });

      if (!agentErr && agentData && agentData.length > 0) {
        setAgents(agentData.map(normalizeAgent) as typeof mockAgents);
        anyLive = true;
      } else {
        setAgents(mockAgents);
      }
    } catch {
      setAgents(mockAgents);
    }

    // Documents/Plugins/Configs/Notifications — fallback mock (pas de tables Supabase dédiées)
    setDocuments(mockDocs);
    setPlugins(mockPlugins);
    setConfigurations(mockConfigs);
    setNotifications(mockNotifs);

    setIsLive(anyLive);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    loading,
    error,
    isLive,
    rules,
    triggers,
    agents,
    documents,
    plugins,
    configurations,
    notifications,
    globalStats: mockStats,
    refetch: fetchData,
  };
}



