import { useState, useEffect, useMemo, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import {
  TEST_BLOCS,
  TEST_BLOC_META,
  computeTestBlocKPIs,
  type TestBloc,
  type TestBlocKPIs,
  type TestFinding,
  type CorrectifAction,
} from '@/mocks/testsParBloc';

type TabId = 'overview' | 'detail' | 'correctifs' | 'tous';

interface UseKOSTestsParBlocReturn {
  meta: typeof TEST_BLOC_META;
  kpis: TestBlocKPIs;
  blocs: TestBloc[];
  selectedBloc: TestBloc | null;
  setSelectedBloc: (bloc: TestBloc | null) => void;
  activeTab: TabId;
  setActiveTab: (tab: TabId) => void;
  categoryFilter: string;
  setCategoryFilter: (cat: string) => void;
  filteredBlocs: TestBloc[];
  allFindings: TestFinding[];
  allCorrectifs: CorrectifAction[];
  severityFilter: string;
  setSeverityFilter: (severity: string) => void;
  correctifFilter: string;
  setCorrectifFilter: (filter: string) => void;
  filteredFindings: TestFinding[];
  filteredCorrectifs: CorrectifAction[];
  loading: boolean;
  refresh: () => void;
  runAllTests: () => void;
  scanning: boolean;
  lastScanResult: string | null;
  isLive: boolean;
}

export function useKOSTestsParBloc(): UseKOSTestsParBlocReturn {
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [lastScanResult, setLastScanResult] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [selectedBloc, setSelectedBloc] = useState<TestBloc | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [correctifFilter, setCorrectifFilter] = useState<string>('all');
  const [isLive, setIsLive] = useState(false);

  const meta = TEST_BLOC_META;
  const kpis = useMemo(() => computeTestBlocKPIs(), []);
  const blocs = TEST_BLOCS;

  const filteredBlocs = useMemo(() => {
    if (categoryFilter === 'all') return blocs;
    if (categoryFilter === 'optimal') return blocs.filter(b => b.status === 'optimal');
    if (categoryFilter === 'surveillance') return blocs.filter(b => b.status === 'surveillance' || b.status === 'critique');
    if (categoryFilter === 'critique') return blocs.filter(b => b.status === 'critique');
    return blocs.filter(b => b.category === categoryFilter);
  }, [blocs, categoryFilter]);

  const allFindings = useMemo(() => {
    if (selectedBloc) return selectedBloc.findings;
    return blocs.flatMap(b => b.findings);
  }, [blocs, selectedBloc]);

  const allCorrectifs = useMemo(() => {
    if (selectedBloc) return selectedBloc.correctifs;
    return blocs.flatMap(b => b.correctifs);
  }, [blocs, selectedBloc]);

  const filteredFindings = useMemo(() => {
    if (severityFilter === 'all') return allFindings;
    return allFindings.filter(f => f.severity === severityFilter);
  }, [allFindings, severityFilter]);

  const filteredCorrectifs = useMemo(() => {
    if (correctifFilter === 'all') return allCorrectifs;
    if (correctifFilter === 'pending') return allCorrectifs.filter(c => c.status === 'pending');
    if (correctifFilter === 'running') return allCorrectifs.filter(c => c.status === 'running');
    if (correctifFilter === 'auto') return allCorrectifs.filter(c => c.type === 'auto' || c.type === 'semi-auto');
    if (correctifFilter === 'p0') return allCorrectifs.filter(c => c.priority === 'P0');
    return allCorrectifs.filter(c => c.type === correctifFilter);
  }, [allCorrectifs, correctifFilter]);

  const fetchSupabase = useCallback(async () => {
    try {
      const { data, error: supabaseError } = await supabase
        .from('kos_block_scans')
        .select('*')
        .order('last_scan', { ascending: false })
        .limit(10);

      if (supabaseError) throw supabaseError;
      if (data && data.length > 0) setIsLive(true);
    } catch {
      setIsLive(false);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 400);
    fetchSupabase();
    return () => clearTimeout(timer);
  }, [fetchSupabase]);

  const refresh = () => {
    setLoading(true);
    fetchSupabase();
    setTimeout(() => setLoading(false), 400);
  };

  const runAllTests = () => {
    setScanning(true);
    setLastScanResult(null);
    setTimeout(() => {
      setScanning(false);
      setLastScanResult('Scan complet terminé — 10 blocs, 18 437 tests exécutés en 47 secondes');
    }, 2500);
  };

  return {
    meta,
    kpis,
    blocs,
    selectedBloc,
    setSelectedBloc,
    activeTab,
    setActiveTab,
    categoryFilter,
    setCategoryFilter,
    filteredBlocs,
    allFindings,
    allCorrectifs,
    severityFilter,
    setSeverityFilter,
    correctifFilter,
    setCorrectifFilter,
    filteredFindings,
    filteredCorrectifs,
    loading,
    refresh,
    runAllTests,
    scanning,
    lastScanResult,
    isLive,
  };
}



