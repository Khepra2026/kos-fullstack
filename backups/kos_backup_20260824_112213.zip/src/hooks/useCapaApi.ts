import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import type { MassCapaAction } from '@/mocks/massCapa';

// ─── HELPERS ───────────────────────────────────────────
async function invokeCapa(action: string, payload?: Record<string, unknown>) {
  const { data, error } = await supabase.functions.invoke('kos-capa-api', {
    body: { action, ...payload },
  });
  if (error) throw error;
  return data as Record<string, unknown>;
}

// ─── HOOKS ─────────────────────────────────────────────
export function useCapaList() {
  return useQuery({
    queryKey: ['capa'],
    queryFn: async () => {
      const res = await invokeCapa('list');
      return (res.rows || []) as MassCapaAction[];
    },
    retry: 1,
    staleTime: 30000,
  });
}

export function useCapaBulkCreate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({
      items,
      batchId,
      auditUser,
    }: {
      items: Partial<MassCapaAction>[];
      batchId: string;
      auditUser: string;
    }) => {
      const res = await invokeCapa('bulk_create', {
        items,
        batchId,
        auditUser,
      });
      return res;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['capa'] });
    },
  });
}

export function useKosUpgrade() {
  return useMutation({
    mutationFn: async ({ userId, modelVersion }: { userId?: string; modelVersion?: string }) => {
      const res = await invokeCapa('upgrade', { userId, modelVersion });
      return res;
    },
  });
}

export function useCapaHealth() {
  return useQuery({
    queryKey: ['capa-health'],
    queryFn: async () => {
      const res = await invokeCapa('health');
      return res;
    },
    retry: false,
    staleTime: Infinity,
  });
}



