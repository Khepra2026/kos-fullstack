import { useState, useCallback } from 'react';
import { computePhaseMetrics, usePhaseLoading, usePhaseLiveData } from '@/hooks/usePhaseDataCore';
import {
  phase5Stats,
  phase5Chantiers,
  phase5ExecutionLog,
  phase5Timeline,
  phase5Budget,
  phase5Dependencies,
} from '@/mocks/phase5Expansion';

export function usePhase5Expansion() {
  const [retryCount, setRetryCount] = useState(0);
  const loading = usePhaseLoading(retryCount);
  const retry = useCallback(() => setRetryCount(c => c + 1), []);
  const { liveData, isLive } = usePhaseLiveData(5);

  const m = computePhaseMetrics(phase5Chantiers, 38500000, 4200000, '2026-08-26', '2026-09-09');

  return {
    loading,
    retry,
    isLive,
    liveData,
    phase5Stats,
    phase5Chantiers,
    phase5ExecutionLog,
    phase5Timeline,
    phase5Budget,
    phase5Dependencies,
    openChantiers: m.openItems,
    inProgressChantiers: m.inProgressItems,
    completedChantiers: m.completedItems,
    totalActions: m.totalActions,
    completedActions: m.completedActions,
    inProgressActions: m.inProgressActions,
    globalProgress: m.globalProgress,
    criticalPathBlockers: m.criticalPathBlockers,
    daysRemaining: m.daysRemaining,
    budgetUtilizationPercent: m.budgetUtilizationPercent,
  };
}



