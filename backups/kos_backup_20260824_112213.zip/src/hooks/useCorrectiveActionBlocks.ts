import { useState, useMemo, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import {
  CORRECTIVE_ACTION_BLOCKS,
  BLOCS_META,
  computeBlockKPIs,
} from '@/mocks/correctiveActionBlocks';
import type { CorrectiveActionBlock } from '@/mocks/correctiveActionBlocks';

export type BlocViewTab = 'dashboard' | 'bloc' | 'actions' | 'kpis' | 'dependances' | 'budget' | 'mass';
export type BlocFilter = 'all' | 'P0' | 'P1' | 'P2' | 'critique' | 'en_cours';
export type SortMode = 'priorite' | 'score' | 'budget';

export function useCorrectiveActionBlocks() {
  const [activeTab, setActiveTab] = useState<BlocViewTab>('dashboard');
  const [activeBlocId, setActiveBlocId] = useState<string | null>(null);
  const [blocFilter, setBlocFilter] = useState<BlocFilter>('all');
  const [sortMode, setSortMode] = useState<SortMode>('priorite');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedActions, setExpandedActions] = useState<Set<string>>(new Set());
  const [isLive, setIsLive] = useState(false);
  const [blocs, setBlocs] = useState<CorrectiveActionBlock[]>(CORRECTIVE_ACTION_BLOCKS);

  const refetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: liveData, error: supabaseErr } = await supabase
        .from('kos_corrective_blocks')
        .select('*');
      if (!supabaseErr && liveData && liveData.length > 0) {
        const normalized = (liveData as any[]).map((row: any) => ({
          ...row,
          actions: Array.isArray(row.actions) ? row.actions : [],
          kpis: Array.isArray(row.kpis) ? row.kpis : [],
          references: Array.isArray(row.references) ? row.references : [],
          dependances: Array.isArray(row.dependances) ? row.dependances : [],
          impacts_axes: Array.isArray(row.impacts_axes) ? row.impacts_axes : [],
          impact_risques: Array.isArray(row.impact_risques) ? row.impact_risques : [],
        }));
        setBlocs(normalized as unknown as CorrectiveActionBlock[]);
        setIsLive(true);
      } else {
        setBlocs(CORRECTIVE_ACTION_BLOCKS);
        setIsLive(false);
        if (supabaseErr) setError(supabaseErr.message);
      }
    } catch (e) {
      setBlocs(CORRECTIVE_ACTION_BLOCKS);
      setIsLive(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refetch();
  }, [refetch]);

  const kpis = useMemo(() => computeBlockKPIs(), []);

  const filteredBlocs = useMemo(() => {
    let filtered = [...blocs];
    if (blocFilter === 'P0') filtered = filtered.filter(b => b.priorite_globale === 'P0');
    if (blocFilter === 'P1') filtered = filtered.filter(b => b.priorite_globale === 'P1');
    if (blocFilter === 'P2') filtered = filtered.filter(b => b.priorite_globale === 'P2');
    if (blocFilter === 'critique') filtered = filtered.filter(b => b.statut_global === 'critique');
    if (blocFilter === 'en_cours') filtered = filtered.filter(b => b.statut_global === 'en_cours');

    if (sortMode === 'score') filtered.sort((a, b) => a.score_bloc_actuel - b.score_bloc_actuel);
    else if (sortMode === 'budget') filtered.sort((a, b) => {
      const parseBudget = (s: string) => parseInt(s.replace(/[^0-9]/g, ''));
      return parseBudget(b.budget_total) - parseBudget(a.budget_total);
    });
    else {
      const prioriteOrdre: Record<string, number> = { P0: 0, P1: 1, P2: 2 };
      filtered.sort((a, b) => prioriteOrdre[a.priorite_globale] - prioriteOrdre[b.priorite_globale]);
    }
    return filtered;
  }, [blocs, blocFilter, sortMode]);

  const activeBloc = useMemo(
    () => (activeBlocId ? blocs.find(b => b.id === activeBlocId) || null : null),
    [activeBlocId, blocs],
  );

  const allBlockActions = useMemo(() => {
    return (blocs || []).flatMap(b => (Array.isArray(b.actions) ? b.actions : []).map(a => ({ ...a, bloc_nom: b.nom, bloc_id: b.id, bloc_couleur: b.couleur })));
  }, [blocs]);

  const navigateToBloc = useCallback((blocId: string) => {
    setActiveBlocId(blocId);
    setActiveTab('bloc');
  }, []);

  const toggleActionExpanded = useCallback((actionId: string) => {
    setExpandedActions(prev => {
      const next = new Set(prev);
      if (next.has(actionId)) next.delete(actionId);
      else next.add(actionId);
      return next;
    });
  }, []);

  return {
    blocs,
    filteredBlocs,
    allBlockActions,
    meta: BLOCS_META,
    kpis,
    activeTab,
    setActiveTab,
    activeBloc,
    activeBlocId,
    navigateToBloc,
    blocFilter,
    setBlocFilter,
    sortMode,
    setSortMode,
    expandedActions,
    toggleActionExpanded,
    loading,
    error,
    refetch,
    isLive,
  };
}



