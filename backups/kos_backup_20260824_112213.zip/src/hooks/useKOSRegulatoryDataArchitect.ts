import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import {
  ARCHITECTURE_SCENARIOS,
  ARCHITECTURE_DELIVERABLES,
  ARCHITECTURE_AGENTS,
  ARCHITECTURE_KPIS,
} from '@/mocks/regulatoryDataArchitect';
import type { ArchitectureScenario, ArchitectureDeliverable } from '@/mocks/regulatoryDataArchitect';

interface UseKOSRegulatoryDataArchitectReturn {
  scenarios: ArchitectureScenario[];
  deliverables: ArchitectureDeliverable[];
  agents: typeof ARCHITECTURE_AGENTS;
  kpis: typeof ARCHITECTURE_KPIS;
  selectedDeliverable: ArchitectureDeliverable | null;
  processing: boolean;
  error: string | null;
  selectScenario: (id: string) => void;
  loading: boolean;
  refetch: () => void;
  isLive: boolean;
}

export function useKOSRegulatoryDataArchitect(): UseKOSRegulatoryDataArchitectReturn {
  const [selectedDeliverable, setSelectedDeliverable] = useState<ArchitectureDeliverable | null>(null);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLive, setIsLive] = useState(false);

  const refetch = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data: liveData, error: supabaseErr } = await supabase
        .from('enterprise_architecture')
        .select('*')
        .limit(1);
      if (!supabaseErr && liveData && liveData.length > 0) {
        setIsLive(true);
      }
    } catch {
      // fallback silencieux au mock
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refetch();
  }, [refetch]);

  const selectScenario = useCallback((id: string) => {
    setProcessing(true);
    setError(null);
    setTimeout(() => {
      const found = ARCHITECTURE_DELIVERABLES.find(d => d.scenario.id === id);
      if (found) {
        setSelectedDeliverable(found);
      } else {
        setError('Scénario d\'architecture non trouvé. Veuillez réessayer.');
      }
      setProcessing(false);
    }, 1500);
  }, []);

  return {
    scenarios: ARCHITECTURE_SCENARIOS,
    deliverables: ARCHITECTURE_DELIVERABLES,
    agents: ARCHITECTURE_AGENTS,
    kpis: ARCHITECTURE_KPIS,
    selectedDeliverable,
    processing,
    error,
    selectScenario,
    loading,
    refetch,
    isLive,
  };
}



