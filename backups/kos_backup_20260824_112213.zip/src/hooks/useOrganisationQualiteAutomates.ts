import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { KOS_ORGANISATION_QUALITE_AUTOMATES as mockAutomates, ORGANISATION_QUALITE_CATEGORIES as mockCategories, ORGANISATION_QUALITE_KPIS as mockKPIs } from '@/mocks/organisationQualiteAutomates';
import type { organisationQualiteAutomate, OrganisationQualiteCategory } from '@/mocks/organisationQualiteAutomates';

export type { organisationQualiteAutomate, OrganisationQualiteCategory };

export interface OrganisationQualiteKPIs {
  total_agents: number;
  deployed: number;
  partial: number;
  mock: number;
  auto_enabled: number;
  total_audits_completed: number;
  total_non_conformities: number;
  overall_quality_score: number;
  total_certifications: number;
  total_processes_managed: number;
  total_tasks: number;
  avg_success_rate: number;
  critical_agents: number;
  high_priority: number;
  medium_priority: number;
  categories: number;
}

export interface OrganisationQualiteData {
  automates: organisationQualiteAutomate[];
  categories: OrganisationQualiteCategory[];
  kpis: OrganisationQualiteKPIs;
  isLive: boolean;
}

function mapAutomate(row: Record<string, unknown>): organisationQualiteAutomate {
  return {
    id: row.id as string,
    name: row.name as string,
    category: row.category as string,
    tech_stack: typeof row.tech_stack === 'string' ? (row.tech_stack ? row.tech_stack.split(',').map((s: string) => s.trim()) : []) : Array.isArray(row.tech_stack) ? row.tech_stack as string[] : [],
    status: row.status as organisationQualiteAutomate['status'],
    version: row.version as string,
    description: row.description as string,
    capabilities: typeof row.capabilities === 'string' ? (row.capabilities ? row.capabilities.split(',').map((s: string) => s.trim()) : []) : Array.isArray(row.capabilities) ? row.capabilities as string[] : [],
    success_rate: Number(row.success_rate),
    tasks_completed: Number(row.tasks_completed),
    auto_enabled: Boolean(row.auto_enabled),
    icon: row.icon as string,
    color: row.color as string,
    last_execution: row.last_execution as string,
    priority: row.priority as organisationQualiteAutomate['priority'],
    kpis: Array.isArray(row.kpis) ? row.kpis as organisationQualiteAutomate['kpis'] : [],
    audits_completed: Number(row.audits_completed),
    non_conformities_detected: Number(row.non_conformities_detected),
    quality_score: Number(row.quality_score),
    certifications_maintained: Number(row.certifications_maintained),
    processes_managed: Number(row.processes_managed),
  };
}

export function useOrganisationQualiteAutomates() {
  const [data, setData] = useState<OrganisationQualiteData>({
    automates: [],
    categories: [],
    kpis: { total_agents: 0, deployed: 0, partial: 0, mock: 0, auto_enabled: 0, total_audits_completed: 0, total_non_conformities: 0, overall_quality_score: 0, total_certifications: 0, total_processes_managed: 0, total_tasks: 0, avg_success_rate: 0, critical_agents: 0, high_priority: 0, medium_priority: 0, categories: 0 },
    isLive: false,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const { data: automates, error: err } = await supabase
        .from('kos_organisation_qualite_automates')
        .select('*')
        .order('success_rate', { ascending: false });

      if (err) throw err;

      const rows = (automates as Record<string, unknown>[]) || [];
      const mapped = rows.map(mapAutomate);
      const hasData = mapped.length > 0;

      const computedKPIs: OrganisationQualiteKPIs = {
        total_agents: mapped.length,
        deployed: mapped.filter(a => a.status === 'deployed').length,
        partial: mapped.filter(a => a.status === 'partial').length,
        mock: mapped.filter(a => a.status === 'mock').length,
        auto_enabled: mapped.filter(a => a.auto_enabled).length,
        total_audits_completed: mapped.reduce((s, a) => s + (a.audits_completed || 0), 0),
        total_non_conformities: mapped.reduce((s, a) => s + (a.non_conformities_detected || 0), 0),
        overall_quality_score: mapped.length > 0 ? Math.round(mapped.reduce((s, a) => s + a.quality_score, 0) / mapped.length * 10) / 10 : 0,
        total_certifications: mapped.reduce((s, a) => s + (a.certifications_maintained || 0), 0),
        total_processes_managed: mapped.reduce((s, a) => s + (a.processes_managed || 0), 0),
        total_tasks: mapped.reduce((s, a) => s + (a.tasks_completed || 0), 0),
        avg_success_rate: mapped.length > 0 ? Math.round(mapped.reduce((s, a) => s + a.success_rate, 0) / mapped.length * 10) / 10 : 0,
        critical_agents: mapped.filter(a => a.priority === 'critical').length,
        high_priority: mapped.filter(a => a.priority === 'high').length,
        medium_priority: mapped.filter(a => a.priority === 'medium').length,
        categories: [...new Set(mapped.map(a => a.category))].length,
      };

      setData({
        automates: mapped,
        categories: mockCategories,
        kpis: computedKPIs,
        isLive: hasData,
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur inconnue';
      setError(message);
      setData({
        automates: mockAutomates,
        categories: mockCategories,
        kpis: mockKPIs as OrganisationQualiteKPIs,
        isLive: false,
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { ...data, loading, error, refetch: fetchData };
}



