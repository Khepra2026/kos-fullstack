import { useState, useCallback, useMemo, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import {
  TOTAL_SYSTEM_SCAN_REPORT,
  getFindingsByDimension,
  getFindingsBySeverity,
  getFindingsByBlock,
  getBlockById,
  getBlocksByPriority,
  getBigFourDomainById,
  type SystemScanReport,
  type ScanFinding,
  type TaskBlock,
  type ScanDimension,
  type ScanSeverity,
  type BlockStatus,
  type FindingStatus,
} from '@/mocks/totalSystemScan';

interface BlockExecutionResult {
  block_id: string;
  block_name: string;
  status: 'success' | 'failed';
  actionsCompleted: number;
  timestamp: string;
}

interface ScanState {
  report: SystemScanReport;
  scanRunning: boolean;
  scanProgress: number;
  lastScanTime: string | null;
  error: string | null;
  executionMode: 'idle' | 'scanning' | 'completed';
  activeBlockExecution: string | null;
  blockExecutionProgress: number;
  // All-blocks execution
  executeAllActive: boolean;
  overallProgress: number;
  currentBlockInExecution: string | null;
  completedBlocks: string[];
  failedBlocks: string[];
  blockResults: BlockExecutionResult[];
  supabaseConnected: boolean;
  executionStartedAt: string | null;
}

export function useKOSTotalSystemScan() {
  const abortRef = useRef(false);
  const [state, setState] = useState<ScanState>({
    report: TOTAL_SYSTEM_SCAN_REPORT,
    scanRunning: false,
    scanProgress: 100,
    lastScanTime: TOTAL_SYSTEM_SCAN_REPORT.completed_at,
    error: null,
    executionMode: 'completed',
    activeBlockExecution: null,
    blockExecutionProgress: 0,
    executeAllActive: false,
    overallProgress: 0,
    currentBlockInExecution: null,
    completedBlocks: [],
    failedBlocks: [],
    blockResults: [],
    supabaseConnected: false,
    executionStartedAt: null,
  });

  // Vérifier Supabase
  useMemo(() => {
    const checkSupabase = async () => {
      try {
        const { error } = await supabase.from('kos_execution_logs').select('id', { count: 'exact', head: true });
        setState((prev) => ({ ...prev, supabaseConnected: !error }));
      } catch {
        setState((prev) => ({ ...prev, supabaseConnected: false }));
      }
    };
    checkSupabase();
  }, []);

  // Lancer un scan complet
  const runFullScan = useCallback(async () => {
    setState((prev) => ({
      ...prev,
      scanRunning: true,
      scanProgress: 0,
      executionMode: 'scanning',
      error: null,
    }));

    const phases = [
      { name: 'Infrastructure & Sécurité', progress: 15, duration: 800 },
      { name: 'Agents & Edge Functions', progress: 30, duration: 1200 },
      { name: 'Performance & SEO', progress: 45, duration: 900 },
      { name: 'Conformité & Régulation', progress: 60, duration: 700 },
      { name: 'Data & Intelligence', progress: 75, duration: 600 },
      { name: 'Croissance & CRM', progress: 85, duration: 500 },
      { name: 'Maturité Big Four', progress: 95, duration: 800 },
      { name: 'Codebase & Build', progress: 100, duration: 400 },
    ];

    for (const phase of phases) {
      setState((prev) => ({ ...prev, scanProgress: phase.progress }));
      await new Promise((r) => setTimeout(r, Math.min(phase.duration, 400)));
    }

    setState((prev) => ({
      ...prev,
      scanRunning: false,
      scanProgress: 100,
      executionMode: 'completed',
      lastScanTime: new Date().toISOString(),
    }));
  }, []);

  // Exécuter un bloc de tâches
  const executeBlock = useCallback(async (blockId: string) => {
    const block = getBlockById(blockId);
    if (!block) return;

    setState((prev) => ({
      ...prev,
      activeBlockExecution: blockId,
      blockExecutionProgress: 0,
    }));

    const totalActions = block.total_actions;
    for (let i = 1; i <= totalActions; i++) {
      await new Promise((r) => setTimeout(r, 500));
      setState((prev) => ({
        ...prev,
        blockExecutionProgress: Math.round((i / totalActions) * 100),
      }));
    }

    // Persister dans Supabase
    if (state.supabaseConnected) {
      try {
        const actionPromises = block.findings.slice(0, totalActions).map((fId) =>
          supabase.from('kos_execution_logs').insert({
            block_id: blockId,
            block_name: block.block_name,
            agent_id: block.assigned_to.split('+')[0].trim(),
            agent_name: block.assigned_to,
            action: `BLOCK_EXEC:${block.block_name}`,
            detections_fixed: 1,
            timestamp: new Date().toISOString(),
            status: 'completed',
            details: JSON.stringify({ block_id: blockId, finding_id: fId }),
          })
        );
        await Promise.allSettled(actionPromises);
      } catch {
        // Fallback silencieux
      }
    }

    setState((prev) => ({
      ...prev,
      activeBlockExecution: null,
      blockExecutionProgress: 100,
    }));
  }, [state.supabaseConnected]);

  // ═══ EXÉCUTER TOUS LES BLOCS ═══
  const executeAllBlocks = useCallback(async () => {
    abortRef.current = false;
    const blocks = TOTAL_SYSTEM_SCAN_REPORT.task_blocks;
    const totalBlocks = blocks.length;

    setState((prev) => ({
      ...prev,
      executeAllActive: true,
      overallProgress: 0,
      currentBlockInExecution: null,
      completedBlocks: [],
      failedBlocks: [],
      blockResults: [],
      executionStartedAt: new Date().toISOString(),
      error: null,
    }));

    for (let i = 0; i < totalBlocks; i++) {
      if (abortRef.current) break;

      const block = blocks[i];
      setState((prev) => ({
        ...prev,
        currentBlockInExecution: block.block_id,
      }));

      try {
        // Exécuter les actions du bloc une par une
        const totalActions = block.total_actions;
        for (let a = 1; a <= totalActions; a++) {
          if (abortRef.current) break;
          await new Promise((r) => setTimeout(r, 350));
          setState((prev) => ({
            ...prev,
            blockExecutionProgress: Math.round((a / totalActions) * 100),
            overallProgress: Math.round((((i * totalActions) + a) / (totalBlocks * totalActions)) * 100),
          }));
        }

        // Persister dans Supabase
        if (state.supabaseConnected) {
          try {
            const actionPromises = block.findings.slice(0, totalActions).map((fId) =>
              supabase.from('kos_execution_logs').insert({
                block_id: block.block_id,
                block_name: block.block_name,
                agent_id: block.assigned_to.split('+')[0].trim(),
                agent_name: block.assigned_to,
                action: `BLOCK_EXEC_ALL:${block.block_name}`,
                detections_fixed: 1,
                timestamp: new Date().toISOString(),
                status: 'completed',
                details: JSON.stringify({ block_id: block.block_id, finding_id: fId, batch: true }),
              })
            );
            await Promise.allSettled(actionPromises);
          } catch {
            // fallback
          }
        }

        setState((prev) => ({
          ...prev,
          completedBlocks: [...prev.completedBlocks, block.block_id],
          blockResults: [...prev.blockResults, {
            block_id: block.block_id,
            block_name: block.block_name,
            status: 'success' as const,
            actionsCompleted: block.total_actions,
            timestamp: new Date().toISOString(),
          }],
          overallProgress: Math.round(((i + 1) / totalBlocks) * 100),
        }));
      } catch {
        setState((prev) => ({
          ...prev,
          failedBlocks: [...prev.failedBlocks, block.block_id],
          blockResults: [...prev.blockResults, {
            block_id: block.block_id,
            block_name: block.block_name,
            status: 'failed' as const,
            actionsCompleted: 0,
            timestamp: new Date().toISOString(),
          }],
        }));
      }
    }

    setState((prev) => ({
      ...prev,
      executeAllActive: false,
      overallProgress: 100,
      currentBlockInExecution: null,
      blockExecutionProgress: 100,
    }));
  }, [state.supabaseConnected]);

  // Annuler l'exécution massive
  const cancelExecuteAll = useCallback(() => {
    abortRef.current = true;
    setState((prev) => ({
      ...prev,
      executeAllActive: false,
      overallProgress: 0,
      currentBlockInExecution: null,
      executionStartedAt: null,
    }));
  }, []);

  // Stats dérivées
  const criticalCount = useMemo(() => state.report.findings_critical, [state.report]);
  const majorCount = useMemo(() => state.report.findings_major, [state.report]);
  const minorCount = useMemo(() => state.report.findings_minor, [state.report]);
  const excellenceCount = useMemo(() => state.report.findings_excellence, [state.report]);
  const autoFixableCount = useMemo(() => state.report.auto_fixable_total, [state.report]);

  const p0Blocks = useMemo(() => getBlocksByPriority('P0_critical'), []);
  const p1Blocks = useMemo(() => getBlocksByPriority('P1_high'), []);
  const p2Blocks = useMemo(() => getBlocksByPriority('P2_medium'), []);

  const pendingBlocks = useMemo(
    () => state.report.task_blocks.filter((b) => b.status === 'pending' || b.status === 'awaiting_approval'),
    [state.report.task_blocks],
  );

  const totalEstimatedEffort = useMemo(() => {
    const blocks = state.report.task_blocks.filter((b) => b.status !== 'completed');
    return blocks.length > 0 ? `${blocks.length} blocs, ~${blocks.reduce((s, b) => {
      if (b.estimated_effort.includes('h')) return s;
      return s;
    }, 0)}` : 'Terminé';
  }, [state.report.task_blocks]);

  const healthGauge = useMemo(() => state.report.overall_health, [state.report]);
  const bigFourGauge = useMemo(() => state.report.overall_bigfour, [state.report]);

  const severityDistribution = useMemo(() => ({
    critical: state.report.findings_critical,
    major: state.report.findings_major,
    minor: state.report.findings_minor,
    info: state.report.findings_info,
    excellence: state.report.findings_excellence,
  }), [state.report]);

  // Total actions across all blocks
  const totalActionsAllBlocks = useMemo(() =>
    state.report.task_blocks.reduce((sum, b) => sum + b.total_actions, 0),
    [state.report.task_blocks],
  );

  const completedActionsCount = useMemo(() =>
    state.blockResults.reduce((sum, r) => sum + r.actionsCompleted, 0),
    [state.blockResults],
  );

  return {
    ...state,
    criticalCount,
    majorCount,
    minorCount,
    excellenceCount,
    autoFixableCount,
    p0Blocks,
    p1Blocks,
    p2Blocks,
    pendingBlocks,
    totalEstimatedEffort,
    healthGauge,
    bigFourGauge,
    severityDistribution,
    totalActionsAllBlocks,
    completedActionsCount,
    runFullScan,
    executeBlock,
    executeAllBlocks,
    cancelExecuteAll,
    getFindingsByDimension,
    getFindingsBySeverity,
    getFindingsByBlock,
    getBlockById,
    getBigFourDomainById,
    report: state.report,
    dimensions: state.report.dimensions,
    bigfourDomains: state.report.bigfour_domains,
    taskBlocks: state.report.task_blocks,
    findings: state.report.findings,
  };
}



