import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { KOS_DEV_AUTOMATES as mockAutomates, DEV_AUTOMATE_CATEGORIES as mockCategories, DEV_AUTOMATES_KPIS as mockKPIs } from '@/mocks/fullstackDevAutomates';
import type { devAutomate, DevAutomateCategory } from '@/mocks/fullstackDevAutomates';

export type { devAutomate, DevAutomateCategory };

export interface DevAutomatesKPIs {
  total_agents: number;
  deployed: number;
  partial: number;
  mock: number;
  auto_enabled: number;
  total_tasks: number;
  avg_success_rate: number;
  critical_agents: number;
  high_priority: number;
  categories: number;
}

export interface FullstackDevAutomatesData {
  automates: devAutomate[];
  categories: DevAutomateCategory[];
  kpis: DevAutomatesKPIs;
  isLive: boolean;
}

function mapAutomate(row: Record<string, unknown>): devAutomate {
  return {
    id: row.id as string,
    name: row.name as string,
    category: row.category as string,
    tech_stack: (row.tech_stack as string[]) || [],
    status: row.status as devAutomate['status'],
    version: row.version as string,
    description: row.description as string,
    capabilities: (row.capabilities as string[]) || [],
    success_rate: Number(row.success_rate),
    tasks_completed: Number(row.tasks_completed),
    auto_enabled: Boolean(row.auto_enabled),
    icon: row.icon as string,
    color: row.color as string,
    last_execution: row.last_execution as string,
    priority: row.priority as devAutomate['priority'],
    kpis: (row.kpis as devAutomate['kpis']) || [],
  };
}

export function useFullstackDevAutomates() {
  const [data, setData] = useState<FullstackDevAutomatesData>({
    automates: [],
    categories: [],
    kpis: { total_agents: 0, deployed: 0, partial: 0, mock: 0, auto_enabled: 0, total_tasks: 0, avg_success_rate: 0, critical_agents: 0, high_priority: 0, categories: 0 },
    isLive: false,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const { data: automates, error: err } = await supabase
        .from('kos_dev_automates')
        .select('*')
        .order('success_rate', { ascending: false });

      if (err) throw err;

      const rows = (automates as Record<string, unknown>[]) || [];
      const mapped = rows.map(mapAutomate);
      const hasData = mapped.length > 0;

      const computedKPIs: DevAutomatesKPIs = {
        total_agents: mapped.length,
        deployed: mapped.filter(a => a.status === 'deployed').length,
        partial: mapped.filter(a => a.status === 'partial').length,
        mock: mapped.filter(a => a.status === 'mock').length,
        auto_enabled: mapped.filter(a => a.auto_enabled).length,
        total_tasks: mapped.reduce((s, a) => s + a.tasks_completed, 0),
        avg_success_rate: mapped.length > 0 ? Math.round(mapped.reduce((s, a) => s + a.success_rate, 0) / mapped.length * 10) / 10 : 0,
        critical_agents: mapped.filter(a => a.priority === 'critical').length,
        high_priority: mapped.filter(a => a.priority === 'high').length,
        categories: [...new Set(mapped.map(a => a.category))].length,
      };

      setData({
        automates: mapped,
        categories: mockCategories,
        kpis: computedKPIs,
        isLive: hasData,
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erreur inconnue';
      setError(message);
      setData({
        automates: mockAutomates,
        categories: mockCategories,
        kpis: mockKPIs as DevAutomatesKPIs,
        isLive: false,
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return { ...data, loading, error, refetch: fetchData };
}



