import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { hubs } from '@/mocks/dashboard';
import notificationBell from '@/components/feature/notificationBell';

interface hubSwitcherProps {
  currentHubId: number;
  activeTab?: string;
  tabLabel?: string;
}

const colorMap: Record<string, string> = {
  primary: 'bg-primary-100 text-primary-700',
  accent: 'bg-accent-100 text-accent-700',
  secondary: 'bg-secondary-100 text-secondary-700',
};

export default function hubSwitcher({ currentHubId, activeTab, tabLabel }: hubSwitcherProps) {
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentIndex = hubs.findIndex(h => h.id === currentHubId);
  const currentHub = hubs[currentIndex];
  const totalHubs = hubs.length;

  const prevIndex = currentIndex > 0 ? currentIndex - 1 : totalHubs - 1;
  const nextIndex = currentIndex < totalHubs - 1 ? currentIndex + 1 : 0;
  const prevHub = hubs[prevIndex];
  const nextHub = hubs[nextIndex];

  const phasesWithHubs = hubs.reduce<Record<string, typeof hubs>>((acc, hub) => {
    if (!acc[hub.phase]) acc[hub.phase] = [];
    acc[hub.phase].push(hub);
    return acc;
  }, {});

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    if (showDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showDropdown]);

  if (!currentHub) return null;

  return (
    <div className="border-b border-background-200/70 bg-background-50">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between py-2">
          {/* Left side: Previous + Breadcrumb */}
          <div className="flex items-center gap-2 min-w-0">
            <Link
              to={prevHub.slug}
              className="w-6 h-6 flex items-center justify-center rounded-md text-foreground-400 hover:text-foreground-700 hover:bg-background-100 transition-colors flex-shrink-0 cursor-pointer"
              title={`← ${prevHub.name}`}
            >
              <i className="ri-arrow-left-s-line text-sm"></i>
            </Link>

            <div className="flex items-center gap-1 text-xs font-body overflow-hidden">
              <Link
                to="/kos-dashboard"
                className="text-foreground-400 hover:text-primary-500 transition-colors whitespace-nowrap cursor-pointer"
              >
                KOS Dashboard
              </Link>
              <i className="ri-arrow-right-s-line text-[10px] text-foreground-300 flex-shrink-0"></i>
              <span className="text-foreground-600 font-medium truncate">{currentHub.name}</span>
              {activeTab && tabLabel && (
                <>
                  <i className="ri-arrow-right-s-line text-[10px] text-foreground-300 flex-shrink-0"></i>
                  <span className="text-foreground-500 truncate">{tabLabel}</span>
                </>
              )}
            </div>

            <span className="text-[10px] text-foreground-300 flex-shrink-0 ml-1 hidden sm:inline">
              {currentIndex + 1}/{totalHubs}
            </span>
          </div>

          {/* Right side: Dropdown + Notifications + Next */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="flex items-center gap-1 px-2.5 py-1 text-xs text-foreground-500 hover:text-foreground-700 hover:bg-background-100 rounded-md transition-colors cursor-pointer font-body whitespace-nowrap"
              >
                <i className="ri-grid-line text-sm"></i>
                <span className="hidden sm:inline">Tous les hubs</span>
                <i className={`ri-arrow-down-s-line text-[10px] transition-transform duration-200 ${showDropdown ? 'rotate-180' : ''}`}></i>
              </button>

              {showDropdown && (
                <div className="absolute right-0 top-full mt-1 z-50 w-72 max-h-[55vh] overflow-y-auto bg-background-50 border border-background-200/70 rounded-lg shadow-lg py-2">
                  <div className="px-3 py-1.5 border-b border-background-200/70 mb-1">
                    <p className="text-[11px] font-semibold text-foreground-400 uppercase tracking-wider font-body">Naviguer vers un hub</p>
                  </div>
                  {Object.entries(phasesWithHubs).map(([phase, hubs]) => (
                    <div key={phase} className="mb-1 last:mb-0">
                      <div className="px-3 py-1 text-[10px] font-semibold text-foreground-400 uppercase tracking-wider font-body">
                        {phase}
                      </div>
                      {hubs.map(hub => (
                        <Link
                          key={hub.id}
                          to={hub.slug}
                          onClick={() => setShowDropdown(false)}
                          className={`flex items-center gap-2.5 px-3 py-1.5 text-xs transition-colors cursor-pointer ${
                            hub.id === currentHubId
                              ? 'bg-primary-50 text-primary-700 font-medium'
                              : 'text-foreground-600 hover:bg-background-100'
                          }`}
                        >
                          <div className={`w-6 h-6 flex items-center justify-center rounded flex-shrink-0 ${colorMap[hub.colorToken] || 'bg-primary-100 text-primary-700'}`}>
                            <i className={`${hub.icon} text-[11px]`}></i>
                          </div>
                          <span className="truncate font-body">{hub.name}</span>
                          {hub.alerts > 0 && (
                            <span className="ml-auto flex-shrink-0 w-4 h-4 flex items-center justify-center rounded-full bg-red-100 text-red-700 text-[9px] font-bold">
                              {hub.alerts}
                            </span>
                          )}
                        </Link>
                      ))}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <notificationBell />

            <Link
              to={nextHub.slug}
              className="w-6 h-6 flex items-center justify-center rounded-md text-foreground-400 hover:text-foreground-700 hover:bg-background-100 transition-colors flex-shrink-0 cursor-pointer"
              title={`${nextHub.name} →`}
            >
              <i className="ri-arrow-right-s-line text-sm"></i>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}



