import { Link } from 'react-router-dom';
import { getCrossLinksForArticle, type CrossLink } from '@/mocks/articleCrossLinks';
import { ARTICLES_GENERATED } from '@/mocks/generatedArticles';

interface ArticleCrossLinksProps {
  articleSlug: string;
  className?: string;
}

const THEME_ICONS: Record<string, string> = {
  'Adéquation': 'ri-funds-line',
  'Gouvernance': 'ri-organization-chart',
  'Risques': 'ri-alert-line',
  'Capital': 'ri-money-dollar-circle-line',
  'ICAAP': 'ri-line-chart-line',
  'Conformité': 'ri-shield-check-line',
  'Transparence': 'ri-eye-line',
  'Reporting': 'ri-file-chart-line',
  'Digital': 'ri-smartphone-line',
  'Cyber': 'ri-shield-keyhole-line',
  'KYC': 'ri-user-search-line',
  'Supervision': 'ri-government-line',
  'Finance': 'ri-bank-line',
  'Inclusion': 'ri-community-line',
  'ESG': 'ri-leaf-line',
  'Climat': 'ri-temp-hot-line',
  'Résilience': 'ri-shield-flash-line',
  'Tests': 'ri-test-tube-line',
  'Flux': 'ri-exchange-line',
  'Impact': 'ri-pulse-line',
  'Décisions': 'ri-scales-line',
  'Protection': 'ri-lock-line',
  'Fonds Propres': 'ri-funds-box-line',
  'SFd': 'ri-home-smile-line',
};

function getThemeIcon(theme: string): string {
  for (const [key, icon] of Object.entries(THEME_ICONS)) {
    if (theme.includes(key)) return icon;
  }
  return 'ri-link-m';
}

export default function ArticleCrossLinks({ articleSlug, className = '' }: ArticleCrossLinksProps) {
  const crossLinks = getCrossLinksForArticle(articleSlug);

  if (crossLinks.length === 0) return null;

  return (
    <section className={`mb-10 ${className}`}>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-8 h-8 rounded-lg bg-background-200/70 flex items-center justify-center">
          <i className="ri-node-tree text-foreground-700" />
        </div>
        <h2 className="text-xl md:text-2xl font-bold text-foreground-950 font-heading">
          Articles Connexes — Pour Aller Plus Loin
        </h2>
      </div>

      <p className="text-sm text-foreground-600 mb-6 leading-relaxed">
        Ces analyses complètent et approfondissent les enjeux abordés dans cet article. 
        Chaque lien est contextualisé pour vous guider vers la lecture la plus pertinente selon vos priorités.
      </p>

      <div className="grid sm:grid-cols-2 gap-4">
        {crossLinks.map((link) => {
          const targetArticle = ARTICLES_GENERATED.find(a => a.slug === link.slug);
          const themeIcon = getThemeIcon(link.theme);

          return (
            <Link
              key={link.slug}
              to={`/blog/${link.slug}`}
              className="group block p-5 rounded-2xl bg-background-100 border border-background-200 hover:border-background-300/80 hover:bg-background-50 transition-all duration-300 cursor-pointer"
            >
              {/* Thème badge */}
              <div className="flex items-center gap-2 mb-3">
                <span className="w-6 h-6 rounded-md bg-primary-500/10 flex items-center justify-center flex-shrink-0">
                  <i className={`${themeIcon} text-xs text-primary-600`} />
                </span>
                <span className="text-xs font-bold uppercase tracking-wider text-foreground-400">
                  {link.theme}
                </span>
              </div>

              {/* Titre */}
              <h3 className="font-bold text-foreground-950 text-sm mb-2 group-hover:text-primary-600 transition-colors leading-snug">
                {link.title}
              </h3>

              {/* Connexion */}
              <p className="text-xs text-foreground-600 leading-relaxed mb-3">
                {link.connection}
              </p>

              {/* Métadonnées de l'article cible */}
              {targetArticle && (
                <div className="flex items-center gap-3 text-xs text-foreground-400">
                  <span className="flex items-center gap-1">
                    <i className="ri-user-line" />
                    {targetArticle.author}
                  </span>
                  <span className="flex items-center gap-1">
                    <i className="ri-time-line" />
                    {targetArticle.readTime}
                  </span>
                </div>
              )}

              {/* Flèche hover */}
              <div className="flex items-center gap-1 mt-3 text-xs font-semibold text-primary-500 opacity-0 group-hover:opacity-100 transition-opacity">
                <span>Lire l'article</span>
                <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          );
        })}
      </div>

      {/* Lien vers le hub blog */}
      <div className="mt-6 pt-6 border-t border-background-200">
        <Link
          to="/blog"
          className="inline-flex items-center gap-2 text-sm font-semibold text-foreground-600 hover:text-primary-600 transition-colors cursor-pointer"
        >
          <i className="ri-article-line" />
          <span>Explorer tous les articles du KOS Think Tank</span>
          <i className="ri-arrow-right-line text-xs" />
        </Link>
      </div>
    </section>
  );
}



